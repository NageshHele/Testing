﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace FeedLibrary.Data_Structures
{
    public class MBPEventArgs : EventArgs
    {
        static string _Empty = "-";
        public string Token { get; set; } = _Empty;
        public string VolumeTradedToday { get; set; } = _Empty;
        public string LastTradedPrice { get; set; } = _Empty;
        public string PercentChange { get; set; } = _Empty;
        public string LastTradeQuantity { get; set; } = _Empty;
        public string LastTradeTime { get; set; } = _Empty;
        public string AverageTradePrice { get; set; } = _Empty;
        public string ClosingPrice { get; set; } = _Empty;
        public string OpenPrice { get; set; } = _Empty;
        public string HighPrice { get; set; } = _Empty;
        public string LowPrice { get; set; } = _Empty;
        public string BuyPrice { get; set; } = _Empty;
        public string BuyQuantity { get; set; } = _Empty;
        public string SellPrice { get; set; } = _Empty;
        public string SellQuantity { get; set; } = _Empty;
        public string IV { get; set; } = _Empty;
        public string UnderlyingPrice { get; set; } = _Empty;
        public string MarketVolume { get; set; } = _Empty;
        public string Delta { get; set; } = _Empty;
        public string Theta { get; set; } = _Empty;
        public string Gamma { get; set; } = _Empty;
        public string Vega { get; set; } = _Empty;
        public string TotalBuyQuantity { get; set; } = _Empty;
        public string TotalSellQuantity { get; set; } = _Empty;
        public string OI { get; set; } = _Empty;
    }

    public class Packet7208T
    {
        static string _Empty = "-";
        public string Token { get; set; } = _Empty;
        public string VolumeTradedToday { get; set; } = _Empty;
        public string LastTradedPrice { get; set; } = _Empty;
        public string PercentChange { get; set; } = _Empty;
        public string LastTradeQuantity { get; set; } = _Empty;
        public string LastTradeTime { get; set; } = _Empty;
        public string AverageTradePrice { get; set; } = _Empty;
        public string ClosingPrice { get; set; } = _Empty;
        public string OpenPrice { get; set; } = _Empty;
        public string HighPrice { get; set; } = _Empty;
        public string LowPrice { get; set; } = _Empty;
        public string BuyPriceDepth { get; set; } = _Empty;
        public string BuyQuantityDepth { get; set; } = _Empty;
        public string BuyOrdersDepth { get; set; } = _Empty;
        public string SellPriceDepth { get; set; } = _Empty;
        public string SellQuantityDepth { get; set; } = _Empty;
        public string SellOrdersDepth { get; set; } = _Empty;
        public string TotalBuyQuantity { get; set; } = _Empty;
        public string TotalSellQuantity { get; set; } = _Empty;
        public string OI { get; set; } = _Empty;
        public string OIPercent { get; set; } = _Empty;
    }
    public class MWEventArgs : EventArgs
    {
        static string _Empty = "-";
        public string Token { get; set; } = _Empty;
        public string OpenInterest { get; set; } = _Empty;
    }
    public class TickerIndexEventArgs : EventArgs
    {
        static string _Empty = "-";
        public string Token { get; set; } = _Empty;
        public string MarketType { get; set; } = _Empty;
        public string FillPrice { get; set; } = _Empty;
        public string FillVolume { get; set; } = _Empty;
        public string OpenInterest { get; set; } = _Empty; // 04/11/2018 mihir
        public string DayHiOI { get; set; } = _Empty;// 04/11/2018 mihir
        public string DayLoOI { get; set; } = _Empty;// 04/11/2018 mihir
        public string Time { get; set; } = _Empty;
    }
    public class FirstPartialCandleEventArgs : EventArgs
    {
        static string _Empty = "-";
        public string Token { get; set; } = _Empty;
        public string Open { get; set; } = _Empty;
        public string High { get; set; } = _Empty;
        public string Low { get; set; } = _Empty;
        public string Close { get; set; } = _Empty;
        public string Volume { get; set; } = _Empty;
        public string CandleTime { get; set; } = _Empty;
    }

    public class BSECMPacket
    {
        static string _Empty = "-";
        public string Token { get; set; } = _Empty;
        public string Open { get; set; } = _Empty;
        public string High { get; set; } = _Empty;
        public string Low { get; set; } = _Empty;
        public string Close { get; set; } = _Empty;
        public string PreviousClose { get; set; } = _Empty;
        public string LTP { get; set; } = _Empty;
        public string LTQ { get; set; } = _Empty;
        public string VolumeTradedToday { get; set; } = _Empty;
        public string AvgPrice { get; set; } = _Empty;
        public string list_BidAskDepth { get; set; }
    }
    //added by Omkar
    public class BSEFOPacket
    {
        static string _Empty = "-";
        public string Token { get; set; } = _Empty;
        public string Open { get; set; } = _Empty;
        public string High { get; set; } = _Empty;
        public string Low { get; set; } = _Empty;
        public string Close { get; set; } = _Empty;
        public string PreviousClose { get; set; } = _Empty;
        public string LTP { get; set; } = _Empty;
        public string LTQ { get; set; } = _Empty;
        public string VolumeTradedToday { get; set; } = _Empty;
        public string AvgPrice { get; set; } = _Empty;
        public string list_BidAskDepth { get; set; }

        public string IV { get; set; } = _Empty;

        public string UnderlyingPrice { get; set; } = _Empty;

        public string Delta { get; set; } = _Empty;
        public string Theta { get; set; } = _Empty;
        public string Gamma { get; set; } = _Empty;
        public string Vega { get; set; } = _Empty;

    }

    public class MCXPacket
    {
        static string _Empty = "-";
        public string Token { get; set; } = _Empty;
        public string Multiplier { get; set; } = "1";
        public string Open { get; set; } = _Empty;
        public string High { get; set; } = _Empty;
        public string Low { get; set; } = _Empty;
        public string Close { get; set; } = _Empty;
        public string LTP { get; set; } = _Empty;
        public string LTQ { get; set; } = _Empty;
        public string LTT { get; set; } = _Empty;
        public string TotalTrades { get; set; } = _Empty;
        public string TotalBuyQty { get; set; } = _Empty;
        public string TotalSellQty { get; set; } = _Empty;
        public string AvgPrice { get; set; } = _Empty;
        public string OpenInterest { get; set; } = _Empty;
        public string list_BidAskDepth { get; set; } = _Empty;
    }

    public class Packet7211Info
    {
        static string _Empty = "-";

        public string Token { get; set; }
        public string LTP { get; set; } = _Empty;
        public string BuyQty { get; set; } = _Empty;
        public string SellQty { get; set; } = _Empty;
        public string LastActiveTime { get; set; } = _Empty;
        public string TradedVolume { get; set; } = _Empty;
        public string TradedValue { get; set; } = _Empty;
        public string TotalOrderVolume1 { get; set; } = _Empty;
        public string TotalOrderVolume2 { get; set; } = _Empty;
        public string Open { get; set; } = _Empty;
        public string High { get; set; } = _Empty;
        public string Low { get; set; } = _Empty;
        public string LastUpdateTime { get; set; } = _Empty;
        public string BidPriceDepth { get; set; } = "-|-|-|-|-";
        public string BidQtyDepth { get; set; } = "-|-|-|-|-";
        public string BidOrdersDepth { get; set; } = "-|-|-|-|-";
        public string AskPriceDepth { get; set; } = "-|-|-|-|-";
        public string AskQtyDepth { get; set; } = "-|-|-|-|-";
        public string AskOrdersDepth { get; set; } = "-|-|-|-|-";
    }

    public class Packet1833Info
    {
        static string _Empty = "-";

        public string Token { get; set; }
        public string TotalQtyTraded { get; set; } = _Empty;
        public string TotValTraded { get; set; } = _Empty;
        public string PercentChange { get; set; } = _Empty;
        public string PrevClose { get; set; } = _Empty;
        public string Open { get; set; } = _Empty;
        public string High { get; set; } = _Empty;
        public string Low { get; set; } = _Empty;
        public string Close { get; set; } = _Empty;
        public string OI { get; set; } = _Empty;
        public string OIPercent { get; set; } = _Empty;
    }

    public class BidAsk
    {
        public double BidPrice { get; set; }
        public long BidQuantity { get; set; }

        public double AskPrice { get; set; }
        public long AskQuantity { get; set; }
    }

    public class FeedReceiverInfo
    {
        public string ID { get; set; } = "FEED";
        public IPAddress IP { get; set; } = IPAddress.Parse("127.0.0.1");
        public int PORT { get; set; } = 0;
        public int Attempts { get; set; } = 0;
        public bool IsConnected { get; set; } = false;
        public Socket FeedSocket { get; set; }
        public bool ToTryReconnect { get; set; } = true;
    }

    public class LTPInfo
    {
        public en_Segment Segment { get; set; }
        public string Token { get; set; }
        public string Time { get; set; }
        public string PriceInPaise { get; set; }
    }

    public enum en_Segment
    {
        NSEFO,
        NSECM,
        BSECM,
        BSEFO,
        NSECD,
        MCX
    }
}
