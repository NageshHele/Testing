﻿//using FeedLibrary.Data_Structures;
//using System;
//using System.Collections.Concurrent;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net;
//using System.Net.Sockets;
//using System.Text;
//using System.Threading;
//using System.Threading.Tasks;

//namespace FeedLibrary
//{
//    public class UDP_Feed
//    {
//        string FO_ID = string.Empty;
//        string CM_ID = string.Empty;
//        string BSECM_ID = string.Empty;

//        IPAddress ip_FOSender = IPAddress.Any;
//        IPAddress ip_CMSender = IPAddress.Any;
//        IPAddress ip_BSECMSender = IPAddress.Any;
//        IPAddress ip_FOReceiver = IPAddress.Any;
//        IPAddress ip_CMReceiver = IPAddress.Any;
//        IPAddress ip_BSECMReceiver = IPAddress.Any;

//        int FO_SenderPORT = 0;
//        int CM_SenderPORT = 0;
//        int BSECM_SenderPORT = 0;
//        int FO_ReceiverPORT = 0;
//        int CM_ReceiverPORT = 0;
//        int BSECM_ReceiverPORT = 0;

//        string PreviousDataFO = string.Empty;
//        string PreviousDataCM = string.Empty;
//        string PreviousDataBSECM = string.Empty;

//        string ProperDataFO = string.Empty;
//        string ProperDataCM = string.Empty;
//        string ProperDataBSECM = string.Empty;

//        const string EOF = "<EOF>";
//        readonly int EOFLength = EOF.Length;

//        int FOAttempts = 0;
//        int CMAttempts = 0;
//        int BSECMAttempts = 0;

//        int FO_EOFIndex = 0;
//        int CM_EOFIndex = 0;
//        int BSECM_EOFIndex = 0;

//        #region Events

//        /// <summary>
//        /// Will be raised depending on the connection status of Feed Receivers.
//        /// </summary>
//        public event del_ConnectionResponse eve_ConnectionResponse;

//        // Added on 14-11-18 by Amey
//        /// <summary>
//        /// Will be raised when FO Exchange packet 7208 is receievd.
//        /// </summary>
//        public event del_7208TickReceived eve_FO7208TickReceived;

//        // Added on 14-11-18 by Amey
//        /// <summary>
//        /// Will be raised when CM Exchange packet 7208 is receievd.
//        /// </summary>
//        public event del_7208TickReceived eve_CM7208TickReceived;

//        /// <summary>
//        /// Will be raised when tick received from BSECM socket.
//        /// </summary>
//        public event del_BSECMTickReceived eve_BSECMTickReceived;

//        #endregion

//        ConcurrentDictionary<string, Socket> dict_FOSenderSockets = new ConcurrentDictionary<string, Socket>();
//        ConcurrentDictionary<string, Socket> dict_CMSenderSockets = new ConcurrentDictionary<string, Socket>();
//        ConcurrentDictionary<string, Socket> dict_BSECMSenderSockets = new ConcurrentDictionary<string, Socket>();

//        IPEndPoint _FOReceiver_EndPoint = null;
//        IPEndPoint _CMReceiver_EndPoint = null;
//        IPEndPoint _BSECMReceiver_EndPoint = null;

//        bool isFOConnected = false;
//        bool isCMConnected = false;
//        bool isBSECMConnected = false;

//        #region Connection Methods

//        /// <summary>
//        /// Will connect to FeedReceievr UDP Broadcast.
//        /// </summary>
//        /// <param name="ID">UniqueID</param>
//        /// <param name="ip_Sender">IP of FeedReceiver</param>\
//        /// <param name="ip_UDPReceiver">IP of current machine to receive UDP feed from FeedReceiver</param>
//        /// <param name="SenderPORT">PORT to send Messages to FeedReceiver</param>
//        /// <param name="UDPReceiverPORT">PORT to receive messages from FeedReceiver</param>
//        public void FOConnect(string ID, IPAddress ip_Sender, IPAddress ip_UDPReceiver, int SenderPORT, int UDPReceiverPORT)
//        {
//            try
//            {
//                var soc_Sender = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
//                dict_FOSenderSockets.AddOrUpdate($"{ip_Sender}:{SenderPORT}", soc_Sender, (oldKey, oldVal) => soc_Sender);

//                FO_ID = ID;
//                ip_FOSender = ip_Sender;
//                ip_FOReceiver = ip_UDPReceiver;
//                FO_SenderPORT = SenderPORT;
//                FO_ReceiverPORT = UDPReceiverPORT;

//                //changed on 18JAN2020 by Amey
//                eve_ConnectionResponse($"FO Listening to [{ip_UDPReceiver}:{UDPReceiverPORT}]");

//                while (!soc_Sender.Connected && (FOAttempts <= 5))
//                {
//                    try
//                    {
//                        FOAttempts++;

//                        //changed on 18JAN2020 by Amey
//                        eve_ConnectionResponse($"FO Connecting to [{ip_Sender}:{SenderPORT}] | Attempts : {FOAttempts}");

//                        soc_Sender.Connect(ip_Sender, SenderPORT);
//                        if (soc_Sender.Connected)
//                        {
//                            isFOConnected = true;

//                            if (_FOReceiver_EndPoint is null)
//                            {
//                                _FOReceiver_EndPoint = new IPEndPoint(ip_UDPReceiver, UDPReceiverPORT);
//                                UdpClient _Receiver = new UdpClient(_FOReceiver_EndPoint);
//                                Task.Run(() => FOPacketReceived(_Receiver));
//                                //_Receiver.BeginReceive(FOPacketReceived, _Receiver);
//                            }

//                            FOAttempts = 0;

//                            string _Message = $"CONNECT^{ID}^{ip_UDPReceiver}^{UDPReceiverPORT}^{EOF}";
//                            SendString(soc_Sender, _Message, "NSEFO");

//                            eve_ConnectionResponse($"FO Connected to [{ip_Sender}:{SenderPORT}]");
//                        }
//                    }
//                    catch (SocketException)
//                    {
//                        if (FOAttempts <= 5)
//                        {
//                            eve_ConnectionResponse($"FO Retrying [{ip_Sender}:{SenderPORT}]");
//                            Thread.Sleep(15000);
//                        }
//                        else
//                            eve_ConnectionResponse($"FO Failed [{ip_Sender}:{SenderPORT}]");
//                    }
//                    catch (Exception ee) { eve_ConnectionResponse("FO : " + $"{ip_Sender}:{SenderPORT}" + Environment.NewLine + ee); }
//                }
//            }
//            catch (Exception ee) { eve_ConnectionResponse("FO : " + $"{ip_Sender}:{SenderPORT}" + Environment.NewLine + ee); }
//        }

//        /// <summary>
//        /// Will connect to FeedReceievr UDP Broadcast.
//        /// </summary>
//        /// <param name="ID">UniqueID</param>
//        /// <param name="ip_Sender">IP of FeedReceiver</param>\
//        /// <param name="ip_UDPReceiver">IP of current machine to receive UDP feed from FeedReceiver</param>
//        /// <param name="SenderPORT">PORT to send Messages to FeedReceiver</param>
//        /// <param name="UDPReceiverPORT">PORT to receive messages from FeedReceiver</param>
//        public void CMConnect(string ID, IPAddress ip_Sender, IPAddress ip_UDPReceiver, int SenderPORT, int UDPReceiverPORT)
//        {
//            try
//            {
//                var soc_Sender = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
//                dict_CMSenderSockets.AddOrUpdate($"{ip_Sender}:{SenderPORT}", soc_Sender, (oldKey, oldVal) => soc_Sender);

//                CM_ID = ID;
//                ip_CMSender = ip_Sender;
//                ip_CMReceiver = ip_UDPReceiver;
//                CM_SenderPORT = SenderPORT;
//                CM_ReceiverPORT = UDPReceiverPORT;

//                //changed on 18JAN2020 by Amey
//                eve_ConnectionResponse($"CM Listening to [{ip_UDPReceiver}:{UDPReceiverPORT}]");

//                while (!soc_Sender.Connected && (CMAttempts <= 5))
//                {
//                    try
//                    {
//                        CMAttempts++;

//                        //changed on 18JAN2020 by Amey
//                        eve_ConnectionResponse($"CM Connecting to [{ip_Sender}:{SenderPORT}] | Attempts : {CMAttempts}");

//                        soc_Sender.Connect(ip_Sender, SenderPORT);
//                        if (soc_Sender.Connected)
//                        {
//                            isCMConnected = true;

//                            if (_CMReceiver_EndPoint is null)
//                            {
//                                _CMReceiver_EndPoint = new IPEndPoint(ip_UDPReceiver, UDPReceiverPORT);
//                                UdpClient _Receiver = new UdpClient(_CMReceiver_EndPoint);
//                                //_Receiver.BeginReceive(CMPacketReceived, _Receiver);
//                                Task.Run(() => CMPacketReceived(_Receiver));
//                            }

//                            CMAttempts = 0;

//                            string _Message = $"CONNECT^{ID}^{ip_UDPReceiver}^{UDPReceiverPORT}^{EOF}";
//                            SendString(soc_Sender, _Message, "NSECM");

//                            eve_ConnectionResponse($"CM Connected to [{ip_Sender}:{SenderPORT}]");
//                        }
//                    }
//                    catch (SocketException)
//                    {
//                        if (CMAttempts <= 5)
//                        {
//                            eve_ConnectionResponse($"CM Retrying [{ip_Sender}:{SenderPORT}]");
//                            Thread.Sleep(15000);
//                        }
//                        else
//                            eve_ConnectionResponse($"CM Failed [{ip_Sender}:{SenderPORT}]");
//                    }
//                    catch (Exception ee) { eve_ConnectionResponse("CM : " + $"{ip_Sender}:{SenderPORT}" + Environment.NewLine + ee); }
//                }
//            }
//            catch (Exception ee) { eve_ConnectionResponse("CM : " + $"{ip_Sender}:{SenderPORT}" + Environment.NewLine + ee); }
//        }

//        /// <summary>
//        /// Will connect to FeedReceievr UDP Broadcast.
//        /// </summary>
//        /// <param name="ID">UniqueID</param>
//        /// <param name="ip_Sender">IP of FeedReceiver</param>\
//        /// <param name="ip_UDPReceiver">IP of current machine to receive UDP feed from FeedReceiver</param>
//        /// <param name="SenderPORT">PORT to send Messages to FeedReceiver</param>
//        /// <param name="UDPReceiverPORT">PORT to receive messages from FeedReceiver</param>
//        public void BSECMConnect(string ID, IPAddress ip_Sender, IPAddress ip_UDPReceiver, int SenderPORT, int UDPReceiverPORT)
//        {
//            try
//            {
//                var soc_Sender = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
//                dict_BSECMSenderSockets.AddOrUpdate($"{ip_Sender}:{SenderPORT}", soc_Sender, (oldKey, oldVal) => soc_Sender);

//                BSECM_ID = ID;
//                ip_BSECMSender = ip_Sender;
//                ip_BSECMReceiver = ip_UDPReceiver;
//                BSECM_SenderPORT = SenderPORT;
//                BSECM_ReceiverPORT = UDPReceiverPORT;

//                //changed on 18JAN2020 by Amey
//                eve_ConnectionResponse($"BSECM Listening to [{ip_UDPReceiver}:{UDPReceiverPORT}]");

//                while (!soc_Sender.Connected && (BSECMAttempts <= 5))
//                {
//                    try
//                    {
//                        BSECMAttempts++;

//                        //changed on 18JAN2020 by Amey
//                        eve_ConnectionResponse($"BSECM Connecting to [{ip_Sender}:{SenderPORT}] | Attempts : {BSECMAttempts}");

//                        soc_Sender.Connect(ip_Sender, SenderPORT);
//                        if (soc_Sender.Connected)
//                        {
//                            isBSECMConnected = true;

//                            if (_BSECMReceiver_EndPoint is null)
//                            {
//                                _BSECMReceiver_EndPoint = new IPEndPoint(ip_UDPReceiver, UDPReceiverPORT);
//                                UdpClient _Receiver = new UdpClient(_BSECMReceiver_EndPoint);
//                                //_Receiver.BeginReceive(BSECMPacketReceived, _Receiver);
//                                Task.Run(() => BSECMPacketReceived(_Receiver));
//                            }

//                            BSECMAttempts = 0;

//                            string _Message = $"CONNECT^{ID}^{ip_UDPReceiver}^{UDPReceiverPORT}^{EOF}";
//                            SendString(soc_Sender, _Message, "BSECM");

//                            eve_ConnectionResponse($"BSECM Connected to [{ip_Sender}:{SenderPORT}]");
//                        }
//                    }
//                    catch (SocketException)
//                    {
//                        if (BSECMAttempts <= 5)
//                        {
//                            eve_ConnectionResponse($"BSECM Retrying [{ip_Sender}:{SenderPORT}]");
//                            Thread.Sleep(15000);
//                        }
//                        else
//                            eve_ConnectionResponse($"BSECM Failed [{ip_Sender}:{SenderPORT}]");
//                    }
//                    catch (Exception ee) { eve_ConnectionResponse("BSECM : " + $"{ip_Sender}:{SenderPORT}" + Environment.NewLine + ee); }
//                }
//            }
//            catch (Exception ee) { eve_ConnectionResponse("BSECM : " + $"{ip_Sender}:{SenderPORT}" + Environment.NewLine + ee); }
//        }

//        #endregion

//        #region Feed Receiver Sending Methods

//        public void FOSubscribe(int _Token)
//        {
//            var list_Keys = dict_FOSenderSockets.Keys.ToList();
//            foreach (var _IP in list_Keys)
//                SendString(dict_FOSenderSockets[_IP], $"SUBSCRIBE^{_Token}^{FO_ID}^{EOF}", "NSEFO");
//        }

//        public void CMSubscribe(int _Token)
//        {
//            var list_Keys = dict_CMSenderSockets.Keys.ToList();
//            foreach (var _IP in list_Keys)
//                SendString(dict_CMSenderSockets[_IP], $"SUBSCRIBE^{_Token}^{CM_ID}^{EOF}", "NSECM");
//        }

//        public void BSECMSubscribe(int _Token)
//        {
//            var list_Keys = dict_BSECMSenderSockets.Keys.ToList();
//            foreach (var _IP in list_Keys)
//                SendString(dict_BSECMSenderSockets[_IP], $"SUBSCRIBE^{_Token}^{BSECM_ID}^{EOF}", "BSECM");
//        }

//        #endregion

//        #region Feed Receiver Receiving Methods

//        //private void FOPacketReceived(IAsyncResult ar)
//        private void FOPacketReceived(UdpClient c)
//        {
//            //UdpClient c = (UdpClient)ar.AsyncState;

//            try
//            {
//                //Byte[] receivedBytes = c.EndReceive(ar, ref _FOReceiver_EndPoint);

//                Byte[] receivedBytes;
//                string receivedText = "";
//                string[] fields;
//                string[] buyPrice;
//                string[] sellPrice;
//                double BuyPrice = 0;
//                double SellPrice = 0;

//                while (isFOConnected)
//                {
//                    receivedBytes = c.Receive(ref _FOReceiver_EndPoint);

//                    receivedText = Encoding.UTF8.GetString(receivedBytes);
//                    PreviousDataFO += receivedText;
//                    while (PreviousDataFO.Contains(EOF))
//                    {
//                        FO_EOFIndex = PreviousDataFO.IndexOf(EOF);
//                        while (FO_EOFIndex == 0)
//                        {
//                            PreviousDataFO = PreviousDataFO.Substring(FO_EOFIndex + EOFLength);
//                            FO_EOFIndex = PreviousDataFO.IndexOf(EOF);
//                        }

//                        if (!PreviousDataFO.Contains(EOF))
//                            continue;

//                        ProperDataFO = PreviousDataFO.Substring(0, FO_EOFIndex - 1);
//                        PreviousDataFO = PreviousDataFO.Substring(FO_EOFIndex + EOFLength);

//                        fields = ProperDataFO.Split('^');

//                        if ("7208".Equals(fields[0]))
//                        {
//                            MBPEventArgs args = new MBPEventArgs();
//                            args.Token = fields[1];
//                            args.VolumeTradedToday = fields[2];
//                            args.LastTradedPrice = (Convert.ToDouble(fields[3]) / 100).ToString();
//                            args.NetPriceChangeFromClosingPrice = (Convert.ToDouble(fields[4]) / 100).ToString();
//                            args.LastTradeQuantity = fields[5];
//                            DateTime dtDateTime = new DateTime(1980, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Local);
//                            dtDateTime = dtDateTime.AddSeconds(Convert.ToDouble(fields[6])).ToLocalTime();
//                            args.LastTradeTime = Convert.ToString(Convert.ToDateTime(dtDateTime).Subtract(new DateTime(1970, 1, 1)).TotalSeconds);
//                            args.AverageTradePrice = (Convert.ToDouble(fields[7]) / 100).ToString();
//                            args.ClosingPrice = (Convert.ToDouble(fields[8]) / 100).ToString();
//                            args.OpenPrice = (Convert.ToDouble(fields[9]) / 100).ToString();
//                            args.HighPrice = (Convert.ToDouble(fields[10]) / 100).ToString();
//                            args.LowPrice = (Convert.ToDouble(fields[11]) / 100).ToString();

//                            if (fields.Count() > 15)
//                            {
//                                buyPrice = fields[12].Split('|');
//                                sellPrice = fields[14].Split('|');
//                                for (int i = 0; i < 5; i++)
//                                {
//                                    //Handled 0 price on 23OCT2020 by Amey.
//                                    BuyPrice = Convert.ToDouble(buyPrice[i]);
//                                    SellPrice = Convert.ToDouble(sellPrice[i]);

//                                    args.BuyPrice += (BuyPrice == 0 ? 0 : BuyPrice / 100) + (i == 4 ? "" : "|");
//                                    args.SellPrice += (SellPrice == 0 ? 0 : SellPrice / 100) + (i == 4 ? "" : "|");
//                                }
//                                args.BuyQuantity = fields[13];
//                                args.SellQuantity = fields[15];
//                            }

//                            if (fields.Count() > 17)
//                            {
//                                args.IV = fields[16];
//                                args.UnderlyingPrice = fields[17];
//                            }

//                            if (fields.Count() > 18)
//                                args.MarketVolume = fields[18];

//                            if (fields.Count() > 22)
//                            {
//                                args.Delta = fields[19];
//                                args.Gamma = fields[20];
//                                args.Theta = fields[21];
//                                args.Vega = fields[22];
//                            }

//                            //changed on 07JAN2021 by Amey
//                            eve_FO7208TickReceived(args);
//                        }
//                    }

//                    Thread.Sleep(10);
//                }
//            }
//            catch (SocketException se) { eve_ConnectionResponse("FO Feed -CON : " + PreviousDataFO + "|" + _FOReceiver_EndPoint.Port + Environment.NewLine + se); }
//            catch (Exception ee) { eve_ConnectionResponse("FO Feed -IN : " + PreviousDataFO + "|" + FO_EOFIndex + Environment.NewLine + ee); }

//            _FOReceiver_EndPoint = null;

//            // Restart listening for udp data packages
//            //c.BeginReceive(FOPacketReceived, ar.AsyncState);
//        }

//        //private void CMPacketReceived(IAsyncResult ar)
//        private void CMPacketReceived(UdpClient c)
//        {
//            //UdpClient c = (UdpClient)ar.AsyncState;

//            try
//            {
//                //Byte[] receivedBytes = c.EndReceive(ar, ref _CMReceiver_EndPoint);

//                Byte[] receivedBytes;
//                string receivedText = "";
//                string[] fields;
//                string[] buyPrice;
//                string[] sellPrice;
//                double BuyPrice = 0;
//                double SellPrice = 0;

//                while (isCMConnected)
//                {
//                    receivedBytes = c.Receive(ref _CMReceiver_EndPoint);

//                    receivedText = Encoding.UTF8.GetString(receivedBytes);
//                    PreviousDataCM += receivedText;
//                    while (PreviousDataCM.Contains(EOF))
//                    {
//                        CM_EOFIndex = PreviousDataCM.IndexOf(EOF);
//                        while (CM_EOFIndex == 0)
//                        {
//                            PreviousDataCM = PreviousDataCM.Substring(CM_EOFIndex + EOFLength);
//                            CM_EOFIndex = PreviousDataCM.IndexOf(EOF);
//                        }

//                        if (!PreviousDataCM.Contains(EOF))
//                            continue;

//                        ProperDataCM = PreviousDataCM.Substring(0, CM_EOFIndex - 1);
//                        PreviousDataCM = PreviousDataCM.Substring(CM_EOFIndex + EOFLength);

//                        fields = ProperDataCM.Split('^');

//                        if ("7208".Equals(fields[0]))
//                        {
//                            MBPEventArgs args = new MBPEventArgs();
//                            args.Token = fields[1];
//                            args.VolumeTradedToday = fields[2];
//                            args.LastTradedPrice = (Convert.ToDouble(fields[3]) / 100).ToString();
//                            args.NetPriceChangeFromClosingPrice = (Convert.ToDouble(fields[4]) / 100).ToString();
//                            args.LastTradeQuantity = fields[5];
//                            DateTime dtDateTime = new DateTime(1980, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Local);
//                            dtDateTime = dtDateTime.AddSeconds(Convert.ToDouble(fields[6])).ToLocalTime();
//                            args.LastTradeTime = Convert.ToString(Convert.ToDateTime(dtDateTime).Subtract(new DateTime(1970, 1, 1)).TotalSeconds);
//                            args.AverageTradePrice = (Convert.ToDouble(fields[7]) / 100).ToString();
//                            args.ClosingPrice = (Convert.ToDouble(fields[8]) / 100).ToString();
//                            args.OpenPrice = (Convert.ToDouble(fields[9]) / 100).ToString();
//                            args.HighPrice = (Convert.ToDouble(fields[10]) / 100).ToString();
//                            args.LowPrice = (Convert.ToDouble(fields[11]) / 100).ToString();

//                            //added on 23OCT2020 by Amey.
//                            if (fields.Count() > 15)
//                            {
//                                buyPrice = fields[12].Split('|');
//                                sellPrice = fields[14].Split('|');
//                                for (int i = 0; i < 5; i++)
//                                {
//                                    //Handled 0 price on 23OCT2020 by Amey.
//                                    BuyPrice = Convert.ToDouble(buyPrice[i]);
//                                    SellPrice = Convert.ToDouble(sellPrice[i]);

//                                    args.BuyPrice += (BuyPrice == 0 ? 0 : BuyPrice / 100) + (i == 4 ? "" : "|");
//                                    args.SellPrice += (SellPrice == 0 ? 0 : SellPrice / 100) + (i == 4 ? "" : "|");
//                                }
//                                args.BuyQuantity = fields[13];
//                                args.SellQuantity = fields[15];
//                            }

//                            if (fields.Count() > 16)
//                                args.MarketVolume = fields[16];

//                            //changed on 07JAN2021 by Amey
//                            eve_CM7208TickReceived(args);
//                        }
//                    }

//                    Thread.Sleep(10);
//                }
//            }
//            catch (SocketException se) { eve_ConnectionResponse("CM Feed -CON : " + PreviousDataFO + "|" + _CMReceiver_EndPoint.Port + Environment.NewLine + se); }
//            catch (Exception ee) { eve_ConnectionResponse("CM Feed -IN : " + PreviousDataFO + "|" + CM_EOFIndex + Environment.NewLine + ee); }

//            _CMReceiver_EndPoint = null;

//            // Restart listening for udp data packages
//            //c.BeginReceive(CMPacketReceived, ar.AsyncState);
//        }

//        //private void BSECMPacketReceived(IAsyncResult ar)
//        private void BSECMPacketReceived(UdpClient c)
//        {
//            //UdpClient c = (UdpClient)ar.AsyncState;

//            try
//            {
//                //Byte[] receivedBytes = c.EndReceive(ar, ref _BSECMReceiver_EndPoint);

//                Byte[] receivedBytes;
//                string receivedText = "";
//                string[] fields;
//                var arr_BidAsk = new int[5] { 10, 11, 12, 13, 14 };
//                var list_BidAsk = new List<BidAsk>();

//                while (isBSECMConnected)
//                {
//                    receivedBytes = c.Receive(ref _BSECMReceiver_EndPoint);

//                    receivedText = Encoding.UTF8.GetString(receivedBytes);
//                    PreviousDataBSECM += receivedText;
//                    while (PreviousDataBSECM.Contains(EOF))
//                    {
//                        BSECM_EOFIndex = PreviousDataBSECM.IndexOf(EOF);
//                        while (BSECM_EOFIndex == 0)
//                        {
//                            PreviousDataBSECM = PreviousDataBSECM.Substring(BSECM_EOFIndex + EOFLength);
//                            BSECM_EOFIndex = PreviousDataBSECM.IndexOf(EOF);
//                        }

//                        if (!PreviousDataBSECM.Contains(EOF))
//                            continue;

//                        ProperDataBSECM = PreviousDataBSECM.Substring(0, BSECM_EOFIndex - 1);
//                        PreviousDataBSECM = PreviousDataBSECM.Substring(BSECM_EOFIndex + EOFLength);

//                        fields = ProperDataBSECM.Split('^');

//                        if (fields.Length > 14)
//                        {
//                            list_BidAsk.Clear();

//                            foreach (var Index in arr_BidAsk)
//                            {
//                                var arr_Values = fields[Index].Split('|');
//                                BidAsk _BidAsk = new BidAsk()
//                                {
//                                    BidPrice = DBL(arr_Values[0]),
//                                    BidQuantity = LONG(arr_Values[1]),
//                                    AskPrice = DBL(arr_Values[2]),
//                                    AskQuantity = LONG(arr_Values[3])
//                                };

//                                list_BidAsk.Add(_BidAsk);
//                            }


//                            BSECMPacket _BSECMPacket = new BSECMPacket()
//                            {
//                                Token = INT(fields[0]),
//                                Open = DBL(fields[1]),
//                                High = DBL(fields[2]),
//                                Low = DBL(fields[3]),
//                                Close = DBL(fields[4]),
//                                PreviousClose = DBL(fields[5]),
//                                LTP = DBL(fields[6]),
//                                LTQ = LONG(fields[7]),
//                                Volume = LONG(fields[8]),
//                                AvgPrice = DBL(fields[9]),
//                                list_BidAskDepth = list_BidAsk
//                            };

//                            eve_BSECMTickReceived(_BSECMPacket);
//                        }
//                    }

//                    Thread.Sleep(10);
//                }
//            }
//            catch (SocketException se) { eve_ConnectionResponse("BSECM Feed -CON : " + PreviousDataBSECM + "|" + _BSECMReceiver_EndPoint.Port + Environment.NewLine + se); }
//            catch (Exception ee) { eve_ConnectionResponse("BSECM Feed -IN : " + PreviousDataBSECM + "|" + BSECM_EOFIndex + Environment.NewLine + ee); }

//            _BSECMReceiver_EndPoint = null;

//            // Restart listening for udp data packages
//            //c.BeginReceive(BSECMPacketReceived, ar.AsyncState);
//        }

//        #endregion

//        #region Supplimentary Methods

//        private void SendString(Socket soc_Sender, string _Message, string SEGMENT = "")
//        {
//            try
//            {
//                //added try catch to handle FeedReceiver disconnection. 16MAR2021-Amey
//                try
//                {
//                    //add .Connected check on 25JAN2021 by Amey
//                    if (soc_Sender != null && soc_Sender.Connected && (SEGMENT == "" || SEGMENT == "NSEFO"))
//                    {
//                        byte[] buffer = Encoding.UTF8.GetBytes(_Message);
//                        soc_Sender.Send(buffer, 0, buffer.Length, SocketFlags.None);
//                    }
//                }
//                catch (SocketException se)
//                {
//                    isFOConnected = false;

//                    eve_ConnectionResponse("FO Feed -CON -SEND : " + _Message + "|" + ((IPEndPoint)soc_Sender.RemoteEndPoint).Port + Environment.NewLine + se);
//                    FOAttempts = 0;

//                    FOConnect(FO_ID, ip_FOSender, ip_FOReceiver, FO_SenderPORT, FO_ReceiverPORT);
//                }

//                //added try catch to handle FeedReceiver disconnection. 16MAR2021-Amey
//                try
//                {
//                    //add .Connected check on 25JAN2021 by Amey
//                    if (soc_Sender != null && soc_Sender.Connected && (SEGMENT == "" || SEGMENT == "NSECM"))
//                    {
//                        byte[] buffer = Encoding.UTF8.GetBytes(_Message);
//                        soc_Sender.Send(buffer, 0, buffer.Length, SocketFlags.None);
//                    }
//                }
//                catch (SocketException se)
//                {
//                    isCMConnected = false;

//                    eve_ConnectionResponse("CM Feed -CON -SEND : " + _Message + "|" + ((IPEndPoint)soc_Sender.RemoteEndPoint).Port + Environment.NewLine + se);
//                    CMAttempts = 0;

//                    CMConnect(CM_ID, ip_CMSender, ip_CMReceiver, CM_SenderPORT, CM_ReceiverPORT);
//                }

//                //added try catch to handle FeedReceiver disconnection. 16MAR2021-Amey
//                try
//                {
//                    //add .Connected check on 25JAN2021 by Amey
//                    if (soc_Sender != null && soc_Sender.Connected && (SEGMENT == "" || SEGMENT == "BSECM"))
//                    {
//                        byte[] buffer = Encoding.UTF8.GetBytes(_Message);
//                        soc_Sender.Send(buffer, 0, buffer.Length, SocketFlags.None);
//                    }
//                }
//                catch (SocketException se)
//                {
//                    isBSECMConnected = false;

//                    eve_ConnectionResponse("BSECM Feed -CON -SEND : " + _Message + "|" + ((IPEndPoint)soc_Sender.RemoteEndPoint).Port + Environment.NewLine + se);
//                    BSECMAttempts = 0;

//                    BSECMConnect(BSECM_ID, ip_BSECMSender, ip_BSECMReceiver, BSECM_SenderPORT, BSECM_ReceiverPORT);
//                }
//            }
//            catch (Exception ee) { eve_ConnectionResponse("FEED : " + _Message + "|" + SEGMENT + Environment.NewLine + ee); }
//        }

//        /// <summary>
//        /// Converts value to double.
//        /// </summary>
//        /// <param name="Value">Pass string value.</param>
//        /// <returns>Value</returns>
//        private static double DBL(string Value) => Convert.ToDouble(Value);

//        /// <summary>
//        /// Converts value to int.
//        /// </summary>
//        /// <param name="Value">Pass string value.</param>
//        /// <returns>Value</returns>
//        private static int INT(string Value) => Convert.ToInt32(Value);

//        /// <summary>
//        /// Converts value to long.
//        /// </summary>
//        /// <param name="Value">Pass string value.</param>
//        /// <returns>Value</returns>
//        private static long LONG(string Value) => Convert.ToInt64(Value);

//        #endregion
//    }
//}
