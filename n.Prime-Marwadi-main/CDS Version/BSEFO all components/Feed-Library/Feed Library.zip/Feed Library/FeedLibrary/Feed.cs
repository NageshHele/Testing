﻿using System;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Win32;
using System.IO;
using System.IO.Compression;
using FeedLibrary.Data_Structures;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace FeedLibrary
{
    //public delegate void del_7208TickReceived(MBPEventArgs Token7208);
    //public delegate void del_7208TTickReceived(Packet7208T _Packet7208T);

    //public delegate void del_7202TickReceived(TickerIndexEventArgs Token7202);
    //public delegate void del_PartialCandleReceived(FirstPartialCandleEventArgs partialCandle);
    //public delegate void del_ConnectionResponse(string status);

    ////added on 22APR2021 by Amey
    //public delegate void del_BSECMTickReceived(BSECMPacket _BSECMPacket);

    ////added on 12JAN2022 by Amey
    //public delegate void del_MCXTickReceived(MCXPacket _MCXPacket);

    public class Feed
    {
        ConcurrentDictionary<string, string[]> dict_FOTokenPacket = new ConcurrentDictionary<string, string[]>();
        ConcurrentDictionary<string, string[]> dict_CMTokenPacket = new ConcurrentDictionary<string, string[]>();
        ConcurrentDictionary<string, string[]> dict_BSECMTokenPacket = new ConcurrentDictionary<string, string[]>();
        ConcurrentDictionary<string, string[]> dict_BSEFOTokenPacket = new ConcurrentDictionary<string, string[]>();//added by omkar
        ConcurrentDictionary<string, string[]> dict_CDTokenPacket = new ConcurrentDictionary<string, string[]>();
        ConcurrentDictionary<string, string[]> dict_MCXTokenPacket = new ConcurrentDictionary<string, string[]>();

        const string EOF = "<EOF>";
        readonly int EOFLength = EOF.Length;

        ConcurrentDictionary<string, FeedReceiverInfo> dict_FOInfo = new ConcurrentDictionary<string, FeedReceiverInfo>();
        ConcurrentDictionary<string, FeedReceiverInfo> dict_CMInfo = new ConcurrentDictionary<string, FeedReceiverInfo>();
        ConcurrentDictionary<string, FeedReceiverInfo> dict_BSECMInfo = new ConcurrentDictionary<string, FeedReceiverInfo>();
        ConcurrentDictionary<string, FeedReceiverInfo> dict_BSEFOInfo = new ConcurrentDictionary<string, FeedReceiverInfo>();//added by omkar
        ConcurrentDictionary<string, FeedReceiverInfo> dict_CDInfo = new ConcurrentDictionary<string, FeedReceiverInfo>();
        ConcurrentDictionary<string, FeedReceiverInfo> dict_MCXInfo = new ConcurrentDictionary<string, FeedReceiverInfo>();

        #region Events

        // Added on 14-11-18 by Amey
        /// <summary>
        /// Will be raised when FO Exchange packet 7208 is receievd.
        /// </summary>
        public event Action<MBPEventArgs> eve_FO7208TickReceived = delegate { };

        /// <summary>
        /// Will be raised when FO Exchange packet 7211 is receievd.
        /// </summary>
        public event Action<Packet7211Info> eve_FO7211TickReceived = delegate { };

        /// <summary>
        /// Will be raised when FO Exchange packet 7208T is receievd.
        /// </summary>
        public event Action<Packet7208T> eve_FO7208TTickReceived = delegate { };

        /// <summary>
        /// Will be raised when CD Exchange packet 7208T is receievd.
        /// </summary>
        public event Action<Packet7208T> eve_CD7208TTickReceived = delegate { };

        /// <summary>
        /// Will be raised when CM Exchange packet 7208T is receievd.
        /// </summary>
        public event Action<Packet7208T> eve_CM7208TTickReceived = delegate { };

        //added on 13OCT2021 by Amey
        public event Action<MBPEventArgs> eve_CD7208TickReceived = delegate { };

        // Added on 14-11-18 by Amey
        /// <summary>
        /// Will be raised when CM Exchange packet 7208 is receievd.
        /// </summary>
        public event Action<MBPEventArgs> eve_CM7208TickReceived = delegate { };

        /// <summary>
        /// Will be raised when Exchange packet 7202 is receievd.
        /// </summary>
        public event Action<TickerIndexEventArgs> eve_7202TickReceived = delegate { };
        /// <summary>
        /// Will be raised when subscribed token for the first time.
        /// </summary>
        public event Action<FirstPartialCandleEventArgs> eve_PartialCandleReceived = delegate { };
        /// <summary>
        /// Will be raised depending on the connection status of Feed Receivers.
        /// </summary>
        public event Action<string> eve_ConnectionResponse = delegate { };

        /// <summary>
        /// Will be raised when tick received from BSECM socket.
        /// </summary>
        public event Action<BSECMPacket> eve_BSECMTickReceived = delegate { };

        //added by Omkar
        /// <summary>
        /// Will be raised when tick received from BSEFO socket.
        /// </summary>
        public event Action<BSEFOPacket> eve_BSEFOTickReceived = delegate { };

        /// <summary>
        /// Will be raised when tick received from MCX socket.
        /// </summary>
        public event Action<MCXPacket> eve_MCXTickReceived = delegate { };

        /// <summary>
        /// Will be raised when tick received from Specific time LTP is received socket.
        /// </summary>
        public event Action<LTPInfo> eve_LTPReceived = delegate { };

        /// <summary>
        /// Will be raised when FO exchange packet 1833 is received.
        /// </summary>
        public event Action<Packet1833Info> eve_FO1833Received = delegate { };

        /// <summary>
        /// Will be raised when CD exchange packet 1833 is received.
        /// </summary>
        public event Action<Packet1833Info> eve_CD1833Received = delegate { };

        /// <summary>
        /// Will be raised when CM exchange packet 1833 is received.
        /// </summary>
        public event Action<Packet1833Info> eve_CM1833Received = delegate { };

        #endregion

        /// <summary>
        /// Call FOConnect and CMConnect using class object.
        /// </summary>
        public Feed() { }

        #region Connection Methods
               

        bool IsCDReceiving = false;
        /// <summary>
        /// Will connect to FeedReceiver CD.
        /// </summary>
        /// <param name="ID">Unique ID</param>
        /// <param name="IP">If set to "auto" => Will pick value from Registry HKEY_CURRENT_USER\\FeedLibrary\\CDBroadcastIP | Else => Pass IP</param>
        /// <param name="PORT">If set to "auto" => Will pick value from Registry HKEY_CURRENT_USER\\FeedLibrary\\CDPORT | Else => Pass PORT</param>
        public void CDConnect(string ID = "FEED", string IP = "127.0.0.1", string PORT = "0", string IPPORT = "", int Timeout = 1000)   // connecting to server
        {
            IPPORT = IPPORT == "" ? $"{IP}:{PORT}" : IPPORT;

            //added on 07MAY2021 by Amey
            if (dict_CDInfo.TryGetValue(IPPORT, out FeedReceiverInfo _FeedReceiverInfo))
            {
                ID = _FeedReceiverInfo.ID;
                IP = _FeedReceiverInfo.IP.ToString();
                PORT = _FeedReceiverInfo.PORT.ToString();

                _FeedReceiverInfo.Attempts = 0;
            }
            else
            {
                _FeedReceiverInfo = new FeedReceiverInfo()
                {
                    ID = ID,
                    IP = IPAddress.Parse(IP),
                    PORT = Convert.ToInt32(PORT),
                    Attempts = 0,
                    IsConnected = false
                };
                dict_CDInfo.TryAdd(IPPORT, _FeedReceiverInfo);
            }

            //added lock on 13SEP2022 by Amey. To only process requests in sequence.
            lock (_FeedReceiverInfo)
            {
                //added on 19MAY2022 by Amey. To avoid multiple connection requests while one is already trying.
                if (_FeedReceiverInfo.ToTryReconnect)
                {
                    _FeedReceiverInfo.ToTryReconnect = false;

                    if (!_FeedReceiverInfo.IsConnected)
                        _FeedReceiverInfo.FeedSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                    while (!_FeedReceiverInfo.IsConnected && (_FeedReceiverInfo.Attempts <= 5))
                    {
                        try
                        {
                            _FeedReceiverInfo.Attempts++;

                            //changed on 18JAN2020 by Amey
                            eve_ConnectionResponse($"CD Connecting to [{IP}:{PORT}] | Attempts : {_FeedReceiverInfo.Attempts} | Thread : {Thread.CurrentThread.ManagedThreadId}");

                            _FeedReceiverInfo.FeedSocket.Connect(_FeedReceiverInfo.IP, _FeedReceiverInfo.PORT);
                            if (_FeedReceiverInfo.FeedSocket.Connected)
                            {
                                _FeedReceiverInfo.Attempts = 0;

                                _FeedReceiverInfo.IsConnected = true;

                                //added SendTimeout on 29NOV2022 by Amey. To avoid any sending block issues over socket.
                                _FeedReceiverInfo.FeedSocket.SendTimeout = Timeout;

                                string TextToSend = $"CONNECT^{ID}^{EOF}";
                                SendString(_FeedReceiverInfo.FeedSocket, TextToSend, IPPORT, en_Segment.NSECD);

                                //changed to Task on 05MAY2021 by Amey
                                //changed to Normal Thread Syntax on 25MAR2021 by Amey
                                Task.Run(() => ReceiveCDResponse(_FeedReceiverInfo.FeedSocket, IPPORT));

                                //added on 30DEC2022 by Amey. To only run one task per segment.
                                if (!IsCDReceiving)
                                {
                                    Task.Run(() => CDSeperateAndSendOut(IPPORT));
                                    IsCDReceiving = true;
                                }

                                eve_ConnectionResponse($"CD Connected to [{IP}:{PORT}] | Thread : {Thread.CurrentThread.ManagedThreadId}");
                            }
                        }
                        catch (SocketException)
                        {
                            if (_FeedReceiverInfo.Attempts <= 5)
                            {
                                //eve_ConnectionResponse($"CD Retrying [{IP}:{PORT}]");
                                Thread.Sleep(15000);
                            }
                            else
                                eve_ConnectionResponse($"CD Failed [{IP}:{PORT}] | Thread : {Thread.CurrentThread.ManagedThreadId}");
                        }
                        catch (Exception ee) { eve_ConnectionResponse("CD : " + $"{IP}:{PORT}" + Environment.NewLine + ee); }
                    }

                    _FeedReceiverInfo.ToTryReconnect = true;
                }
            }
        }

        bool IsFOReceiving = false;
        /// <summary>
        /// Will connect to FeedReceiver FO.
        /// </summary>
        /// <param name="ID">Unique ID</param>
        /// <param name="IP">If set to "auto" => Will pick value from Registry HKEY_CURRENT_USER\\FeedLibrary\\FOBroadcastIP | Else => Pass IP</param>
        /// <param name="PORT">If set to "auto" => Will pick value from Registry HKEY_CURRENT_USER\\FeedLibrary\\FOPORT | Else => Pass PORT</param>
        public void FOConnect(string ID = "FEED", string IP = "127.0.0.1", string PORT = "0", string IPPORT = "", int Timeout = 1000)   // connecting to server
        {
            IPPORT = IPPORT == "" ? $"{IP}:{PORT}" : IPPORT;

            //added on 07MAY2021 by Amey
            if (dict_FOInfo.TryGetValue(IPPORT, out FeedReceiverInfo _FeedReceiverInfo))
            {
                ID = _FeedReceiverInfo.ID;
                IP = _FeedReceiverInfo.IP.ToString();
                PORT = _FeedReceiverInfo.PORT.ToString();

                _FeedReceiverInfo.Attempts = 0;
            }
            else
            {
                _FeedReceiverInfo = new FeedReceiverInfo()
                {
                    ID = ID,
                    IP = IPAddress.Parse(IP),
                    PORT = Convert.ToInt32(PORT),
                    Attempts = 0,
                    IsConnected = false
                };
                dict_FOInfo.TryAdd(IPPORT, _FeedReceiverInfo);
            }

            //added lock on 13SEP2022 by Amey. To only process requests in sequence.
            lock (_FeedReceiverInfo)
            {
               
                //added on 19MAY2022 by Amey. To avoid multiple connection requests while one is already trying.
                if (_FeedReceiverInfo.ToTryReconnect)
                {
                    _FeedReceiverInfo.ToTryReconnect = false;

                    if (!_FeedReceiverInfo.IsConnected)
                        _FeedReceiverInfo.FeedSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    
                    while (!_FeedReceiverInfo.IsConnected && (_FeedReceiverInfo.Attempts <= 5))
                    {
                        try
                        {
                            _FeedReceiverInfo.Attempts++;

                            //changed on 18JAN2020 by Amey
                            eve_ConnectionResponse($"FO Connecting to [{IP}:{PORT}] | Attempts : {_FeedReceiverInfo.Attempts} | Thread : {Thread.CurrentThread.ManagedThreadId}");

                            _FeedReceiverInfo.FeedSocket.Connect(_FeedReceiverInfo.IP, _FeedReceiverInfo.PORT);
                            if (_FeedReceiverInfo.FeedSocket.Connected)
                            {
                                _FeedReceiverInfo.Attempts = 0;

                                _FeedReceiverInfo.IsConnected = true;

                                //added SendTimeout on 29NOV2022 by Amey. To avoid any sending block issues over socket.
                                _FeedReceiverInfo.FeedSocket.SendTimeout = Timeout;

                                string TextToSend = $"CONNECT^{ID}^{EOF}";
                                SendString(_FeedReceiverInfo.FeedSocket, TextToSend, IPPORT, en_Segment.NSEFO);

                                //changed to Task on 05MAY2021 by Amey
                                //changed to Normal Thread Syntax on 25MAR2021 by Amey
                                Task.Run(() => ReceiveFOResponse(_FeedReceiverInfo.FeedSocket, IPPORT));

                                //added on 30DEC2022 by Amey. To only run one task per segment.
                                if (!IsFOReceiving)
                                {
                                    Task.Run(() => FOSeperateAndSendOut(IPPORT));
                                    IsFOReceiving = true;
                                }

                                eve_ConnectionResponse($"FO Connected to [{IP}:{PORT}] | Thread : {Thread.CurrentThread.ManagedThreadId}");
                            }
                        }
                        catch (SocketException)
                        {
                            if (_FeedReceiverInfo.Attempts <= 5)
                            {
                                //eve_ConnectionResponse($"FO Retrying [{IP}:{PORT}]");
                                Thread.Sleep(15000);
                            }
                            else
                                eve_ConnectionResponse($"FO Failed [{IP}:{PORT}] | Thread : {Thread.CurrentThread.ManagedThreadId}");
                        }
                        catch (Exception ee) { eve_ConnectionResponse("FO : " + $"{IP}:{PORT}" + Environment.NewLine + ee); }
                    }

                    _FeedReceiverInfo.ToTryReconnect = true;
                }
            }
        }

        bool IsCMReceiving = false;
        /// <summary>
        /// Will connect to FeedReceiver CM.
        /// </summary>
        /// <param name="ID">Unique ClientID</param>
        /// <param name="IP">If set to "auto" => Will pick value from Registry HKEY_CURRENT_USER\\FeedLibrary\\CMBroadcastIP | Else => Pass IP</param>
        /// <param name="PORT">If set to "auto" => Will pick value from Registry HKEY_CURRENT_USER\\FeedLibrary\\CMPORT | Else => Pass PORT</param>
        public void CMConnect(string ID = "FEED", string IP = "127.0.0.1", string PORT = "0", string IPPORT = "", int Timeout = 1000)   // connecting to server
        {
            IPPORT = IPPORT == "" ? $"{IP}:{PORT}" : IPPORT;

            //added on 07MAY2021 by Amey
            if (dict_CMInfo.TryGetValue(IPPORT, out FeedReceiverInfo _FeedReceiverInfo))
            {
                ID = _FeedReceiverInfo.ID;
                IP = _FeedReceiverInfo.IP.ToString();
                PORT = _FeedReceiverInfo.PORT.ToString();

                _FeedReceiverInfo.Attempts = 0;
            }
            else
            {
                _FeedReceiverInfo = new FeedReceiverInfo()
                {
                    ID = ID,
                    IP = IPAddress.Parse(IP),
                    PORT = Convert.ToInt32(PORT),
                    Attempts = 0,
                    IsConnected = false
                };

                dict_CMInfo.TryAdd(IPPORT, _FeedReceiverInfo);
            }

            //added lock on 13SEP2022 by Amey. To only process requests in sequence.
            lock (_FeedReceiverInfo)
            {
                //added on 19MAY2022 by Amey. To avoid multiple connection requests while one is already trying.
                if (_FeedReceiverInfo.ToTryReconnect)
                {
                    _FeedReceiverInfo.ToTryReconnect = false;

                    _FeedReceiverInfo.FeedSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                    while (!_FeedReceiverInfo.IsConnected && (_FeedReceiverInfo.Attempts <= 5))
                    {
                        try
                        {
                            _FeedReceiverInfo.Attempts++;

                            //changed on 18JAN2020 by Amey
                            eve_ConnectionResponse($"CM Connecting to [{IP}:{PORT}] | Attempts : {_FeedReceiverInfo.Attempts} | Thread : {Thread.CurrentThread.ManagedThreadId}");

                            _FeedReceiverInfo.FeedSocket.Connect(_FeedReceiverInfo.IP, _FeedReceiverInfo.PORT);
                            if (_FeedReceiverInfo.FeedSocket.Connected)
                            {
                                _FeedReceiverInfo.Attempts = 0;

                                _FeedReceiverInfo.IsConnected = true;

                                //added SendTimeout on 29NOV2022 by Amey. To avoid any sending block issues over socket.
                                _FeedReceiverInfo.FeedSocket.SendTimeout = Timeout;

                                string TextToSend = $"CONNECT^{ID}^{EOF}";
                                SendString(_FeedReceiverInfo.FeedSocket, TextToSend, IPPORT, en_Segment.NSECM);

                                //changed to Task on 05MAY2021 by Amey
                                //changed to Normal Thread Syntax on 25MAR2021 by Amey
                                Task.Run(() => ReceiveCMResponse(_FeedReceiverInfo.FeedSocket, IPPORT));

                                //added on 30DEC2022 by Amey. To only run one task per segment.
                                if (!IsCMReceiving)
                                {
                                    Task.Run(() => CMSeperateAndSendOut(IPPORT));
                                    IsCMReceiving = true;
                                }

                                eve_ConnectionResponse($"CM Connected to [{IP}:{PORT}] | Thread : {Thread.CurrentThread.ManagedThreadId}");
                            }
                        }
                        catch (SocketException)
                        {
                            if (_FeedReceiverInfo.Attempts <= 5)
                            {
                                //eve_ConnectionResponse($"CM Retrying [{IP}:{PORT}]");
                                Thread.Sleep(15000);
                            }
                            else
                                eve_ConnectionResponse($"CM Failed [{IP}:{PORT}] | Thread : {Thread.CurrentThread.ManagedThreadId}");
                        }
                        catch (Exception ee) { eve_ConnectionResponse("CM : " + $"{IP}:{PORT}" + Environment.NewLine + ee); }
                    }

                    _FeedReceiverInfo.ToTryReconnect = true;
                }
            }
        }

        bool IsBSECMReceiving = false;
        /// <summary>
        /// Will connect to FeedReceiver BSECM.
        /// </summary>
        /// <param name="ID">Unique ClientID</param>
        /// <param name="IP">If set to "auto" => Will pick value from Registry HKEY_CURRENT_USER\\FeedLibrary\\CMBroadcastIP | Else => Pass IP</param>
        /// <param name="PORT">If set to "auto" => Will pick value from Registry HKEY_CURRENT_USER\\FeedLibrary\\CMPORT | Else => Pass PORT</param>
        public void BSECMConnect(string ID = "FEED", string IP = "127.0.0.1", string PORT = "0", string IPPORT = "", int Timeout = 1000)   // connecting to server
        {
            IPPORT = IPPORT == "" ? $"{IP}:{PORT}" : IPPORT;

            //added on 07MAY2021 by Amey
            if (dict_BSECMInfo.TryGetValue(IPPORT, out FeedReceiverInfo _FeedReceiverInfo))
            {
                ID = _FeedReceiverInfo.ID;
                IP = _FeedReceiverInfo.IP.ToString();
                PORT = _FeedReceiverInfo.PORT.ToString();

                _FeedReceiverInfo.Attempts = 0;
            }
            else
            {
                _FeedReceiverInfo = new FeedReceiverInfo()
                {
                    ID = ID,
                    IP = IPAddress.Parse(IP),
                    PORT = Convert.ToInt32(PORT),
                    Attempts = 0,
                    IsConnected = false
                };

                dict_BSECMInfo.TryAdd(IPPORT, _FeedReceiverInfo);
            }

            //added lock on 13SEP2022 by Amey. To only process requests in sequence.
            lock (_FeedReceiverInfo)
            {
                //added on 19MAY2022 by Amey. To avoid multiple connection requests while one is already trying.
                if (_FeedReceiverInfo.ToTryReconnect)
                {
                    _FeedReceiverInfo.ToTryReconnect = false;

                    _FeedReceiverInfo.FeedSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                    while (!_FeedReceiverInfo.IsConnected && (_FeedReceiverInfo.Attempts <= 5))
                    {
                        try
                        {
                            _FeedReceiverInfo.Attempts++;

                            //changed on 18JAN2020 by Amey
                            eve_ConnectionResponse($"BSECM Connecting to [{IP}:{PORT}] | Attempts : {_FeedReceiverInfo.Attempts} | Thread : {Thread.CurrentThread.ManagedThreadId}");

                            _FeedReceiverInfo.FeedSocket.Connect(_FeedReceiverInfo.IP, _FeedReceiverInfo.PORT);
                            if (_FeedReceiverInfo.FeedSocket.Connected)
                            {
                                _FeedReceiverInfo.Attempts = 0;

                                _FeedReceiverInfo.IsConnected = true;

                                //added SendTimeout on 29NOV2022 by Amey. To avoid any sending block issues over socket.
                                _FeedReceiverInfo.FeedSocket.SendTimeout = 1000;

                                string TextToSend = $"CONNECT^{ID}^{IP}^{PORT}^{EOF}";
                                SendString(_FeedReceiverInfo.FeedSocket, TextToSend, IPPORT, en_Segment.BSECM);

                                //changed to Task on 05MAY2021 by Amey
                                //changed to Normal Thread Syntax on 25MAR2021 by Amey
                                Task.Run(() => ReceiveBSECMResponse(_FeedReceiverInfo.FeedSocket, IPPORT));

                                //added on 30DEC2022 by Amey. To only run one task per segment.
                                if (!IsBSECMReceiving)
                                {
                                    Task.Run(() => BSECMSeperateAndSendOut(IPPORT));
                                    IsBSECMReceiving = true;
                                }

                                eve_ConnectionResponse($"BSECM Connected to [{IP}:{PORT}] | Thread : {Thread.CurrentThread.ManagedThreadId}");
                            }
                        }
                        catch (SocketException)
                        {
                            if (_FeedReceiverInfo.Attempts <= 5)
                            {
                                //eve_ConnectionResponse($"BSECM Retrying [{IP}:{PORT}]");
                                Thread.Sleep(15000);
                            }
                            else
                                eve_ConnectionResponse($"BSECM Failed [{IP}:{PORT}] | Thread : {Thread.CurrentThread.ManagedThreadId}");
                        }
                        catch (Exception ee) { eve_ConnectionResponse("BSECM : " + $"{IP}:{PORT}" + Environment.NewLine + ee); }
                    }

                    _FeedReceiverInfo.ToTryReconnect = true;
                }
            }
        }

        //added by Omkar
        bool IsBSEFOReceiving = false;
        /// <summary>
        /// Will connect to FeedReceiver BSEFO.
        /// </summary>
        /// <param name="ID">Unique ClientID</param>
        /// <param name="IP">If set to "auto" => Will pick value from Registry HKEY_CURRENT_USER\\FeedLibrary\\CMBroadcastIP | Else => Pass IP</param>
        /// <param name="PORT">If set to "auto" => Will pick value from Registry HKEY_CURRENT_USER\\FeedLibrary\\CMPORT | Else => Pass PORT</param>
        public void BSEFOConnect(string ID = "FEED", string IP = "127.0.0.1", string PORT = "0", string IPPORT = "", int Timeout = 1000)   // connecting to server
        {
            IPPORT = IPPORT == "" ? $"{IP}:{PORT}" : IPPORT;

            //added on 07MAY2021 by Amey
            if (dict_BSEFOInfo.TryGetValue(IPPORT, out FeedReceiverInfo _FeedReceiverInfo))
            {
                ID = _FeedReceiverInfo.ID;
                IP = _FeedReceiverInfo.IP.ToString();
                PORT = _FeedReceiverInfo.PORT.ToString();

                _FeedReceiverInfo.Attempts = 0;
            }
            else
            {
                _FeedReceiverInfo = new FeedReceiverInfo()
                {
                    ID = ID,
                    IP = IPAddress.Parse(IP),
                    PORT = Convert.ToInt32(PORT),
                    Attempts = 0,
                    IsConnected = false
                };

                dict_BSEFOInfo.TryAdd(IPPORT, _FeedReceiverInfo);
            }

            //added lock on 13SEP2022 by Amey. To only process requests in sequence.
            lock (_FeedReceiverInfo)
            {
                //added on 19MAY2022 by Amey. To avoid multiple connection requests while one is already trying.
                if (_FeedReceiverInfo.ToTryReconnect)
                {
                    _FeedReceiverInfo.ToTryReconnect = false;

                    _FeedReceiverInfo.FeedSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                    while (!_FeedReceiverInfo.IsConnected && (_FeedReceiverInfo.Attempts <= 5))
                    {
                        try
                        {
                            _FeedReceiverInfo.Attempts++;

                            //changed on 18JAN2020 by Amey
                            eve_ConnectionResponse($"BSEFO Connecting to [{IP}:{PORT}] | Attempts : {_FeedReceiverInfo.Attempts} | Thread : {Thread.CurrentThread.ManagedThreadId}");

                            _FeedReceiverInfo.FeedSocket.Connect(_FeedReceiverInfo.IP, _FeedReceiverInfo.PORT);
                            if (_FeedReceiverInfo.FeedSocket.Connected)
                            {
                                _FeedReceiverInfo.Attempts = 0;

                                _FeedReceiverInfo.IsConnected = true;

                                //added SendTimeout on 29NOV2022 by Amey. To avoid any sending block issues over socket.
                                _FeedReceiverInfo.FeedSocket.SendTimeout = 1000;

                                string TextToSend = $"CONNECT^{ID}^{EOF}";
                                SendString(_FeedReceiverInfo.FeedSocket, TextToSend, IPPORT, en_Segment.BSEFO);

                                //changed to Task on 05MAY2021 by Amey
                                //changed to Normal Thread Syntax on 25MAR2021 by Amey
                                Task.Run(() => ReceiveBSEFOResponse(_FeedReceiverInfo.FeedSocket, IPPORT));
                                // here..
                                //added on 30DEC2022 by Amey. To only run one task per segment.
                                if (!IsBSEFOReceiving)
                                {
                                    Task.Run(() => BSEFOSeperateAndSendOut(IPPORT));
                                    IsBSEFOReceiving = true;
                                }

                                eve_ConnectionResponse($"BSEFO Connected to [{IP}:{PORT}] | Thread : {Thread.CurrentThread.ManagedThreadId}");
                            }
                        }
                        catch (SocketException)
                        {
                            if (_FeedReceiverInfo.Attempts <= 5)
                            {
                                //eve_ConnectionResponse($"BSEFO Retrying [{IP}:{PORT}]");
                                Thread.Sleep(15000);
                            }
                            else
                                eve_ConnectionResponse($"BSEFO Failed [{IP}:{PORT}] | Thread : {Thread.CurrentThread.ManagedThreadId}");
                        }
                        catch (Exception ee) { eve_ConnectionResponse("BSEFO : " + $"{IP}:{PORT}" + Environment.NewLine + ee); }
                    }

                    _FeedReceiverInfo.ToTryReconnect = true;
                }
            }
        }

        bool IsMCXReceiving = false;
        /// <summary>
        /// Will connect to FeedReceiver MCX.
        /// </summary>
        /// <param name="ID">Unique ClientID</param>
        /// <param name="IP">If set to "auto" => Will pick value from Registry HKEY_CURRENT_USER\\FeedLibrary\\CMBroadcastIP | Else => Pass IP</param>
        /// <param name="PORT">If set to "auto" => Will pick value from Registry HKEY_CURRENT_USER\\FeedLibrary\\CMPORT | Else => Pass PORT</param>
        public void MCXConnect(string ID = "FEED", string IP = "127.0.0.1", string PORT = "0", string IPPORT = "", int Timeout = 1000)   // connecting to server
        {
            IPPORT = IPPORT == "" ? $"{IP}:{PORT}" : IPPORT;

            //added on 07MAY2021 by Amey
            if (dict_MCXInfo.TryGetValue(IPPORT, out FeedReceiverInfo _FeedReceiverInfo))
            {
                ID = _FeedReceiverInfo.ID;
                IP = _FeedReceiverInfo.IP.ToString();
                PORT = _FeedReceiverInfo.PORT.ToString();

                _FeedReceiverInfo.Attempts = 0;
            }
            else
            {
                _FeedReceiverInfo = new FeedReceiverInfo()
                {
                    ID = ID,
                    IP = IPAddress.Parse(IP),
                    PORT = Convert.ToInt32(PORT),
                    Attempts = 0,
                    IsConnected = false
                };

                dict_MCXInfo.TryAdd(IPPORT, _FeedReceiverInfo);
            }

            //added lock on 13SEP2022 by Amey. To only process requests in sequence.
            lock (_FeedReceiverInfo)
            {
                //added on 19MAY2022 by Amey. To avoid multiple connection requests while one is already trying.
                if (_FeedReceiverInfo.ToTryReconnect)
                {
                    _FeedReceiverInfo.ToTryReconnect = false;

                    _FeedReceiverInfo.FeedSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                    while (!_FeedReceiverInfo.IsConnected && (_FeedReceiverInfo.Attempts <= 5))
                    {
                        try
                        {
                            _FeedReceiverInfo.Attempts++;

                            //changed on 18JAN2020 by Amey
                            eve_ConnectionResponse($"MCX Connecting to [{IP}:{PORT}] | Attempts : {_FeedReceiverInfo.Attempts} | Thread : {Thread.CurrentThread.ManagedThreadId}");

                            _FeedReceiverInfo.FeedSocket.Connect(_FeedReceiverInfo.IP, _FeedReceiverInfo.PORT);
                            if (_FeedReceiverInfo.FeedSocket.Connected)
                            {
                                _FeedReceiverInfo.Attempts = 0;

                                _FeedReceiverInfo.IsConnected = true;

                                //added SendTimeout on 29NOV2022 by Amey. To avoid any sending block issues over socket.
                                _FeedReceiverInfo.FeedSocket.SendTimeout = Timeout;

                                string TextToSend = $"CONNECT^{ID}^{EOF}";
                                SendString(_FeedReceiverInfo.FeedSocket, TextToSend, IPPORT, en_Segment.MCX);

                                //changed to Task on 05MAY2021 by Amey
                                //changed to Normal Thread Syntax on 25MAR2021 by Amey
                                Task.Run(() => ReceiveMCXResponse(_FeedReceiverInfo.FeedSocket, IPPORT));

                                //added on 30DEC2022 by Amey. To only run one task per segment.
                                if (!IsMCXReceiving)
                                {
                                    Task.Run(() => MCXSeperateAndSendOut(IPPORT));
                                    IsMCXReceiving = true;
                                }

                                eve_ConnectionResponse($"MCX Connected to [{IP}:{PORT}] | Thread : {Thread.CurrentThread.ManagedThreadId}");
                            }
                        }
                        catch (SocketException)
                        {
                            if (_FeedReceiverInfo.Attempts <= 5)
                            {
                                //eve_ConnectionResponse($"MCX Retrying [{IP}:{PORT}]");
                                Thread.Sleep(15000);
                            }
                            else
                                eve_ConnectionResponse($"MCX Failed [{IP}:{PORT}] | Thread : {Thread.CurrentThread.ManagedThreadId}");
                        }
                        catch (Exception ee) { eve_ConnectionResponse("MCX : " + $"{IP}:{PORT}" + Environment.NewLine + ee); }
                    }

                    _FeedReceiverInfo.ToTryReconnect = true;
                }
            }
        }

        #endregion

        #region New reconnecting methods

        //added on 19MAY2022 by Amey. To avoid unnecessary reconnection attempts if closed properly.
        public void TryReconnect(en_Segment _Segment, bool _TryReconnect)
        {
            switch (_Segment)
            {
                case en_Segment.NSEFO:
                    var list_Keys = dict_FOInfo.Keys.ToList();
                    foreach (var SocketKey in list_Keys)
                        if (dict_FOInfo.ContainsKey(SocketKey))
                            dict_FOInfo[SocketKey].ToTryReconnect = _TryReconnect;
                    break;
                case en_Segment.NSECD:
                    list_Keys = dict_CDInfo.Keys.ToList();
                    foreach (var SocketKey in list_Keys)
                        if (dict_CDInfo.ContainsKey(SocketKey))
                            dict_CDInfo[SocketKey].ToTryReconnect = _TryReconnect;
                    break;
                case en_Segment.NSECM:
                    list_Keys = dict_CMInfo.Keys.ToList();
                    foreach (var SocketKey in list_Keys)
                        if (dict_CMInfo.ContainsKey(SocketKey))
                            dict_CMInfo[SocketKey].ToTryReconnect = _TryReconnect;
                    break;
                case en_Segment.BSECM:
                    list_Keys = dict_BSECMInfo.Keys.ToList();
                    foreach (var SocketKey in list_Keys)
                        if (dict_BSECMInfo.ContainsKey(SocketKey))
                            dict_BSECMInfo[SocketKey].ToTryReconnect = _TryReconnect;
                    break;
                case en_Segment.BSEFO:
                    list_Keys = dict_BSEFOInfo.Keys.ToList();
                    foreach (var SocketKey in list_Keys)
                        if (dict_BSEFOInfo.ContainsKey(SocketKey))
                            dict_BSEFOInfo[SocketKey].ToTryReconnect = _TryReconnect;
                    break;
                case en_Segment.MCX:
                    list_Keys = dict_MCXInfo.Keys.ToList();
                    foreach (var SocketKey in list_Keys)
                        if (dict_MCXInfo.ContainsKey(SocketKey))
                            dict_MCXInfo[SocketKey].ToTryReconnect = _TryReconnect;
                    break;
                
            }
        }

        #endregion

        #region Feed Receiver Receiving Methods

        private void ReceiveFOResponse(Socket soc_Sender, string SocketKey)
        {
            int EOFIndex = 0;
            int _ReceivedBytesLength = 0;

            string PreviousData = string.Empty;
            string ProperData = string.Empty;
            string Token = string.Empty;

            string[] arr_Fields;

            byte[] arr_Buffer = new byte[2048];
            byte[] arr_BytesReceived;

            var isConnected = true;
            var args = new MBPEventArgs();
            var TickerIndexArgs = new TickerIndexEventArgs();
            var MWArgs = new MWEventArgs();
            var firstPartialCandleArgs = new FirstPartialCandleEventArgs();

            while (isConnected)
            {
                try
                {
                    _ReceivedBytesLength = soc_Sender.Receive(arr_Buffer, SocketFlags.None);

                    //changed to isConencted = false because 0 means client is closed. 10MAY2021 by Amey
                    //changed to continue on 14JAN2021 by Amey
                    if (_ReceivedBytesLength == 0) { isConnected = false; };

                    arr_BytesReceived = new byte[_ReceivedBytesLength];
                    Array.Copy(arr_Buffer, arr_BytesReceived, _ReceivedBytesLength);

                    PreviousData += Encoding.ASCII.GetString(arr_BytesReceived);
                    while ((EOFIndex = PreviousData.IndexOf(EOF)) >= 0)
                    {
                        //added on 23APR2021 by Amey
                        //To avoid "System.ArgumentOutOfRangeException: Length cannot be less than zero." exception.
                        //EOFIndex = PreviousData.IndexOf(EOF);
                        while (EOFIndex == 0)
                        {
                            PreviousData = PreviousData.Substring(EOFIndex + EOFLength);
                            EOFIndex = PreviousData.IndexOf(EOF);
                        }

                        if (EOFIndex < 0)
                            continue;

                        ProperData = PreviousData.Substring(0, EOFIndex - 1);
                        PreviousData = PreviousData.Substring(EOFIndex + EOFLength);

                        arr_Fields = ProperData.Split('^');
                        Token = arr_Fields[1];

                        //changed to TryAdd on 23FEB2022 by Amey
                        if (!dict_FOTokenPacket.TryAdd(Token, arr_Fields))
                            dict_FOTokenPacket[Token] = arr_Fields;
                    }// end while
                }
                catch (SocketException se)
                {
                    isConnected = false;

                    dict_FOInfo[SocketKey].IsConnected = false;

                    eve_ConnectionResponse("FO Feed -CON : " + se);

                    //added IP and PORT params on 19APR2021 by Amey
                    FOConnect(IPPORT: SocketKey);

                    // Don't shutdown because the socket may be disposed and its disconnected anyway.
                }
                catch (Exception ee)
                {
                    eve_ConnectionResponse("FO Feed -OUT : " + ee);
                }
            }// end while socket connected
        }

        private void ReceiveCDResponse(Socket soc_Sender, string SocketKey)
        {
            int EOFIndex = 0;
            int _ReceivedBytesLength = 0;

            string PreviousData = string.Empty;
            string ProperData = string.Empty;
            string Token = string.Empty;

            string[] arr_Fields;

            byte[] arr_Buffer = new byte[2048];
            byte[] arr_BytesReceived;

            var isConnected = true;
            var args = new MBPEventArgs();
            var TickerIndexArgs = new TickerIndexEventArgs();
            var MWArgs = new MWEventArgs();
            var firstPartialCandleArgs = new FirstPartialCandleEventArgs();

            while (isConnected)
            {
                try
                {
                    _ReceivedBytesLength = soc_Sender.Receive(arr_Buffer, SocketFlags.None);

                    //changed to isConencted = false because 0 means client is closed. 10MAY2021 by Amey
                    //changed to continue on 14JAN2021 by Amey
                    if (_ReceivedBytesLength == 0) { isConnected = false; };

                    arr_BytesReceived = new byte[_ReceivedBytesLength];
                    Array.Copy(arr_Buffer, arr_BytesReceived, _ReceivedBytesLength);

                    PreviousData += Encoding.ASCII.GetString(arr_BytesReceived);
                    while ((EOFIndex = PreviousData.IndexOf(EOF)) >= 0)
                    {
                        //added on 23APR2021 by Amey
                        //To avoid "System.ArgumentOutOfRangeException: Length cannot be less than zero." exception.
                        //EOFIndex = PreviousData.IndexOf(EOF);
                        while (EOFIndex == 0)
                        {
                            PreviousData = PreviousData.Substring(EOFIndex + EOFLength);
                            EOFIndex = PreviousData.IndexOf(EOF);
                        }

                        if (EOFIndex < 0)
                            continue;

                        ProperData = PreviousData.Substring(0, EOFIndex - 1);
                        PreviousData = PreviousData.Substring(EOFIndex + EOFLength);

                        arr_Fields = ProperData.Split('^');
                        Token = arr_Fields[1];

                        if (!dict_CDTokenPacket.TryAdd(Token, arr_Fields))
                            dict_CDTokenPacket[Token] = arr_Fields;
                    }// end while
                }
                catch (SocketException se)
                {
                    isConnected = false;

                    dict_CDInfo[SocketKey].IsConnected = false;

                    eve_ConnectionResponse("CD Feed -CON : " + se);

                    //added IP and PORT params on 19APR2021 by Amey
                    CDConnect(IPPORT: SocketKey);

                    // Don't shutdown because the socket may be disposed and its disconnected anyway.
                }
                catch (Exception ee)
                {
                    eve_ConnectionResponse("CD Feed -OUT : " + ee);
                }
            }// end while socket connected
        }

        private void ReceiveCMResponse(Socket soc_Sender, string SocketKey)
        {
            int EOFIndex = 0;
            int _ReceivedBytesLength = 0;

            string PreviousData = string.Empty;
            string ProperData = string.Empty;
            string Token = string.Empty;

            string[] arr_Fields;

            byte[] arr_Buffer = new byte[2048];
            byte[] arr_BytesReceived;

            var isConnected = true;
            var args = new MBPEventArgs();
            var TickerIndexArgs = new TickerIndexEventArgs();
            var MWArgs = new MWEventArgs();
            var firstPartialCandleArgs = new FirstPartialCandleEventArgs();

            while (isConnected)
            {
                try
                {
                    _ReceivedBytesLength = soc_Sender.Receive(arr_Buffer, SocketFlags.None);

                    //changed to isConencted = false because 0 means client is closed. 10MAY2021 by Amey
                    //changed to continue on 14JAN2021 by Amey
                    if (_ReceivedBytesLength == 0) { isConnected = false; };

                    arr_BytesReceived = new byte[_ReceivedBytesLength];
                    Array.Copy(arr_Buffer, arr_BytesReceived, _ReceivedBytesLength);

                    PreviousData += Encoding.ASCII.GetString(arr_BytesReceived);
                    while ((EOFIndex = PreviousData.IndexOf(EOF)) >= 0)
                    {
                        //added on 23APR2021 by Amey
                        //To avoid "System.ArgumentOutOfRangeException: Length cannot be less than zero." exception.
                        //EOFIndex = PreviousData.IndexOf(EOF);
                        while (EOFIndex == 0)
                        {
                            PreviousData = PreviousData.Substring(EOFIndex + EOFLength);
                            EOFIndex = PreviousData.IndexOf(EOF);
                        }

                        if (EOFIndex < 0)
                            continue;

                        ProperData = PreviousData.Substring(0, EOFIndex - 1);
                        PreviousData = PreviousData.Substring(EOFIndex + EOFLength);

                        arr_Fields = ProperData.Split('^');
                        Token = arr_Fields[1];

                        //changed to TryAdd on 23FEB2022 by Amey
                        if (!dict_CMTokenPacket.TryAdd(Token, arr_Fields))
                            dict_CMTokenPacket[Token] = arr_Fields;
                    }// end while
                }
                catch (SocketException se)
                {
                    isConnected = false;

                    dict_CMInfo[SocketKey].IsConnected = false;

                    eve_ConnectionResponse("CM Feed -CON : " + se);

                    //added IP and PORT params on 19APR2021 by Amey
                    CMConnect(IPPORT: SocketKey);
                    // Don't shutdown because the socket may be disposed and its disconnected anyway.
                }
                catch (Exception ee)
                {
                    eve_ConnectionResponse("CM Feed -OUT : " + ee);
                }
            }// end while socket connected
        }

        private void ReceiveBSECMResponse(Socket soc_Sender, string SocketKey)
        {
            int EOFIndex = 0;
            int _ReceivedBytesLength = 0;

            string PreviousData = string.Empty;
            string ProperData = string.Empty;
            string Token = string.Empty;

            string[] arr_Fields;

            byte[] arr_Buffer = new byte[2048];
            byte[] arr_BytesReceived;

            var isConnected = true;

            while (isConnected)
            {
                try
                {
                    _ReceivedBytesLength = soc_Sender.Receive(arr_Buffer, SocketFlags.None);

                    //changed to continue on 14JAN2021 by Amey
                    if (_ReceivedBytesLength == 0) continue;

                    arr_BytesReceived = new byte[_ReceivedBytesLength];
                    Array.Copy(arr_Buffer, arr_BytesReceived, _ReceivedBytesLength);

                    PreviousData += Encoding.ASCII.GetString(arr_BytesReceived);
                    while ((EOFIndex = PreviousData.IndexOf(EOF)) >= 0)
                    {
                        //added on 23APR2021 by Amey
                        //To avoid "System.ArgumentOutOfRangeException: Length cannot be less than zero." exception.
                        //EOFIndex = PreviousData.IndexOf(EOF);
                        while (EOFIndex == 0)
                        {
                            PreviousData = PreviousData.Substring(EOFIndex + EOFLength);
                            EOFIndex = PreviousData.IndexOf(EOF);
                        }

                        if (EOFIndex < 0)
                            continue;

                        ProperData = PreviousData.Substring(0, EOFIndex - 1);
                        PreviousData = PreviousData.Substring(EOFIndex + EOFLength);

                        arr_Fields = ProperData.Split('^');
                        Token = arr_Fields[1];

                        if (!dict_BSECMTokenPacket.TryAdd(Token, arr_Fields))
                            dict_BSECMTokenPacket[Token] = arr_Fields;
                    }
                }
                catch (SocketException se)
                {
                    isConnected = false;

                    dict_BSECMInfo[SocketKey].IsConnected = false;

                    eve_ConnectionResponse("BSECM Feed -CON : " + PreviousData + Environment.NewLine + se);

                    //added IP and PORT params on 19APR2021 by Amey
                    BSECMConnect(IPPORT: SocketKey);
                }
                catch (Exception ee)
                {
                    eve_ConnectionResponse("BSECM Feed -IN : " + ee);
                }
                //Thread.Sleep(10);
            }
        }

        //added by Omkar
        private void ReceiveBSEFOResponse(Socket soc_Sender, string SocketKey)
        {
            int EOFIndex = 0;
            int _ReceivedBytesLength = 0;

            string PreviousData = string.Empty;
            string ProperData = string.Empty;
            string Token = string.Empty;

            string[] arr_Fields;

            byte[] arr_Buffer = new byte[2048];
            byte[] arr_BytesReceived;

            var isConnected = true;

            while (isConnected)
            {
                try
                {
                    _ReceivedBytesLength = soc_Sender.Receive(arr_Buffer, SocketFlags.None);

                    //changed to continue on 14JAN2021 by Amey
                    if (_ReceivedBytesLength == 0) continue;

                    arr_BytesReceived = new byte[_ReceivedBytesLength];
                    Array.Copy(arr_Buffer, arr_BytesReceived, _ReceivedBytesLength);

                    PreviousData += Encoding.ASCII.GetString(arr_BytesReceived);
                    while ((EOFIndex = PreviousData.IndexOf(EOF)) >= 0)
                    {
                        //added on 23APR2021 by Amey
                        //To avoid "System.ArgumentOutOfRangeException: Length cannot be less than zero." exception.
                        //EOFIndex = PreviousData.IndexOf(EOF);
                        while (EOFIndex == 0)
                        {
                            PreviousData = PreviousData.Substring(EOFIndex + EOFLength);
                            EOFIndex = PreviousData.IndexOf(EOF);
                        }

                        if (EOFIndex < 0)
                            continue;

                        ProperData = PreviousData.Substring(0, EOFIndex - 1);
                        PreviousData = PreviousData.Substring(EOFIndex + EOFLength);

                        arr_Fields = ProperData.Split('^');
                        Token = arr_Fields[1];

                        if (!dict_BSEFOTokenPacket.TryAdd(Token, arr_Fields))
                            dict_BSEFOTokenPacket[Token] = arr_Fields;
                    }
                }
                catch (SocketException se)
                {
                    isConnected = false;

                    dict_BSEFOInfo[SocketKey].IsConnected = false;

                    eve_ConnectionResponse("BSEFO Feed -CON : " + PreviousData + Environment.NewLine + se);

                    //added IP and PORT params on 19APR2021 by Amey
                    BSEFOConnect(IPPORT: SocketKey);
                }
                catch (Exception ee)
                {
                    eve_ConnectionResponse("BSEFO Feed -IN : " + ee);
                }
                //Thread.Sleep(10);
            }
        }

        private void ReceiveMCXResponse(Socket soc_Sender, string SocketKey)
        {
            int EOFIndex = 0;
            int _ReceivedBytesLength = 0;

            string PreviousData = string.Empty;
            string ProperData = string.Empty;
            string Token = string.Empty;

            string[] arr_Fields;

            byte[] arr_Buffer = new byte[2048];
            byte[] arr_BytesReceived;

            var isConnected = true;

            while (isConnected)
            {
                try
                {
                    _ReceivedBytesLength = soc_Sender.Receive(arr_Buffer, SocketFlags.None);

                    //changed to continue on 14JAN2021 by Amey
                    if (_ReceivedBytesLength == 0) continue;

                    arr_BytesReceived = new byte[_ReceivedBytesLength];
                    Array.Copy(arr_Buffer, arr_BytesReceived, _ReceivedBytesLength);

                    PreviousData += Encoding.ASCII.GetString(arr_BytesReceived);
                    while ((EOFIndex = PreviousData.IndexOf(EOF)) >= 0)
                    {
                        //added on 23APR2021 by Amey
                        //To avoid "System.ArgumentOutOfRangeException: Length cannot be less than zero." exception.
                        //EOFIndex = PreviousData.IndexOf(EOF);
                        while (EOFIndex == 0)
                        {
                            PreviousData = PreviousData.Substring(EOFIndex + EOFLength);
                            EOFIndex = PreviousData.IndexOf(EOF);
                        }

                        if (EOFIndex < 0)
                            continue;

                        ProperData = PreviousData.Substring(0, EOFIndex - 1);
                        PreviousData = PreviousData.Substring(EOFIndex + EOFLength);

                        arr_Fields = ProperData.Split('^');
                        Token = arr_Fields[1];

                        if (!dict_MCXTokenPacket.TryAdd(Token, arr_Fields))
                            dict_MCXTokenPacket[Token] = arr_Fields;
                    }
                }
                catch (SocketException se)
                {
                    isConnected = false;

                    dict_MCXInfo[SocketKey].IsConnected = false;

                    eve_ConnectionResponse("MCX Feed -CON : " + PreviousData + Environment.NewLine + se);

                    //added IP and PORT params on 19APR2021 by Amey
                    MCXConnect(IPPORT: SocketKey);
                }
                catch (Exception ee)
                {
                    eve_ConnectionResponse("MCX Feed -IN : " + ee);
                }
                //Thread.Sleep(10);
            }
        }

        #endregion

        #region Feed Receiver Sending Methods

        private void Exit(Socket ClientSocket)
        {
            //TODO: Implement later.
            //SendString("exit"); // Tell the server we are exiting
            //ClientSocket.Shutdown(SocketShutdown.Both);
            ////th.Abort();
            //ClientSocket.Close();
            //Console.WriteLine("Scoket closed");
        }

        /// <summary>
        /// Will subscribe to feed.
        /// </summary>
        /// <param name="_Token">Scrip token</param>
        public void Subscribe(Int64 _Token)
        {
            FOSubscribe(_Token);
            CDSubscribe(_Token);
            CMSubscribe(_Token);
            BSECMSubscribe(_Token);
            BSEFOSubscribe(_Token);
            MCXSubscribe(_Token);
        }

        /// <summary>
        /// Will subscribe to feed.
        /// </summary>
        /// <param name="_Token">Scrip token</param>
        public void FOSubscribe(Int64 _Token)
        {
            var list_Keys = dict_FOInfo.Keys.ToList();
            foreach (var SocketKey in list_Keys)
            {
                var TextToSend = $"SUBSCRIBE^{_Token}^{dict_FOInfo[SocketKey].ID}^{EOF}";
                SendString(dict_FOInfo[SocketKey].FeedSocket, TextToSend, SocketKey, en_Segment.NSEFO);
            }
        }

        /// <summary>
        /// Will subscribe to spread contract feed.
        /// </summary>
        /// <param name="_Token">Scrip token</param>
        public void FOSpreadSubscribe(Int64 _Token)
        {
            var list_Keys = dict_FOInfo.Keys.ToList();
            foreach (var SocketKey in list_Keys)
            {
                var TextToSend = $"SUBSCRIBE^{_Token}^{dict_FOInfo[SocketKey].ID}^{EOF}";
                SendString(dict_FOInfo[SocketKey].FeedSocket, TextToSend, SocketKey, en_Segment.NSEFO);
            }
        }

        public void CDSubscribe(Int64 _Token)
        {
            var list_Keys = dict_CDInfo.Keys.ToList();
            foreach (var SocketKey in list_Keys)
            {
                var TextToSend = $"SUBSCRIBE^{_Token}^{dict_CDInfo[SocketKey].ID}^{EOF}";
                SendString(dict_CDInfo[SocketKey].FeedSocket, TextToSend, SocketKey, en_Segment.NSECD);
            }
        }

        /// <summary>
        /// Will subscribe to feed.
        /// </summary>
        /// <param name="_Token">Scrip token</param>
        public void CMSubscribe(Int64 _Token)
        {
            var list_Keys = dict_CMInfo.Keys.ToList();
            foreach (var SocketKey in list_Keys)
            {
                var TextToSend = $"SUBSCRIBE^{_Token}^{dict_CMInfo[SocketKey].ID}^{EOF}";
                SendString(dict_CMInfo[SocketKey].FeedSocket, TextToSend, SocketKey, en_Segment.NSECM);
            }
        }

        /// <summary>
        /// Will subscribe to feed.
        /// </summary>
        /// <param name="_Token">Scrip token</param>
        public void BSECMSubscribe(Int64 _Token)
        {
            var list_Keys = dict_BSECMInfo.Keys.ToList();
            foreach (var SocketKey in list_Keys)
            {
                var TextToSend = $"SUBSCRIBE^{_Token}^{dict_BSECMInfo[SocketKey].ID}^{EOF}";
                SendString(dict_BSECMInfo[SocketKey].FeedSocket, TextToSend, SocketKey, en_Segment.BSECM);
            }
        }

        //added by Omkar
        /// <summary>
        /// Will subscribe to feed.
        /// </summary>
        /// <param name="_Token">Scrip token</param>
        public void BSEFOSubscribe(Int64 _Token)
        {
            var list_Keys = dict_BSEFOInfo.Keys.ToList();
            foreach (var SocketKey in list_Keys)
            {
                var TextToSend = $"SUBSCRIBE^{_Token}^{dict_BSEFOInfo[SocketKey].ID}^{EOF}";
                SendString(dict_BSEFOInfo[SocketKey].FeedSocket, TextToSend, SocketKey, en_Segment.BSEFO);
            }
        }

        /// <summary>
        /// Will subscribe to feed.
        /// </summary>
        /// <param name="_Token">Scrip token</param>
        public void MCXSubscribe(Int64 _Token)
        {
            var list_Keys = dict_MCXInfo.Keys.ToList();
            foreach (var SocketKey in list_Keys)
            {
                var TextToSend = $"SUBSCRIBE^{_Token}^{dict_MCXInfo[SocketKey].ID}^{EOF}";
                SendString(dict_MCXInfo[SocketKey].FeedSocket, TextToSend, SocketKey, en_Segment.MCX);
            }
        }

        /// <summary>
        /// Will unsubscribe to feed.
        /// </summary>
        /// <param name="_Token">Scrip token</param>
        public void UnSubscribe(Int64 _Token)
        {
            //TODO: Implement later.
            //String str = "UnSubscribe" + "^" + _Token + "^" + FO_ID + "^" + "<EOF>";
            //SendString(str);

            //str = "UnSubscribe" + "^" + _Token + "^" + CM_ID + "^" + "<EOF>";
            //SendString(str);
        }

        #region Added for fetching specific LTP using Time.
        //added on 04JUL2022 bY Amey
        public void GETFOLTP(int UnderlyingToken, DateTime TradeTime)
        {
            var list_Keys = dict_FOInfo.Keys.ToList();
            foreach (var SocketKey in list_Keys)
            {
                var TextToSend = $"GETLTP^{UnderlyingToken}^{TradeTime:ddMMMyyyy HH:mm:ss}^{EOF}";
                SendString(dict_FOInfo[SocketKey].FeedSocket, TextToSend, SocketKey, en_Segment.NSEFO);
            }
        }

        //added on 04JUL2022 bY Amey
        public void GETCMLTP(int SpotToken, DateTime TradeTime)
        {
            var list_Keys = dict_CMInfo.Keys.ToList();
            foreach (var SocketKey in list_Keys)
            {
                var TextToSend = $"GETLTP^{SpotToken}^{TradeTime:ddMMMyyyy HH:mm:ss}^{EOF}";
                SendString(dict_CMInfo[SocketKey].FeedSocket, TextToSend, SocketKey, en_Segment.NSECM);
            }
        }

        //added on 04JUL2022 bY Amey
        public void GETCDLTP(int UnderlyingToken, DateTime TradeTime)
        {
            var list_Keys = dict_CDInfo.Keys.ToList();
            foreach (var SocketKey in list_Keys)
            {
                var TextToSend = $"GETLTP^{UnderlyingToken}^{TradeTime:ddMMMyyyy HH:mm:ss}^{EOF}";
                SendString(dict_CDInfo[SocketKey].FeedSocket, TextToSend, SocketKey, en_Segment.NSECD);
            }
        }

        //added on 04JUL2022 bY Amey
        public void GETMCXLTP(int UnderlyingToken, DateTime TradeTime)
        {
            var list_Keys = dict_MCXInfo.Keys.ToList();
            foreach (var SocketKey in list_Keys)
            {
                var TextToSend = $"GETLTP^{UnderlyingToken}^{TradeTime:ddMMMyyyy HH:mm:ss}^{EOF}";
                SendString(dict_MCXInfo[SocketKey].FeedSocket, TextToSend, SocketKey, en_Segment.MCX);
            }
        }

        //added on 04JUL2022 bY Amey
        public void GETBSECMLTP(int SpotToken, DateTime TradeTime)
        {
            var list_Keys = dict_BSECMInfo.Keys.ToList();
            foreach (var SocketKey in list_Keys)
            {
                var TextToSend = $"GETLTP^{SpotToken}^{TradeTime:ddMMMyyyy HH:mm:ss}^{EOF}";
                SendString(dict_BSECMInfo[SocketKey].FeedSocket, TextToSend, SocketKey, en_Segment.BSECM);
            }
        }

        public void GETBSEFOLTP(int SpotToken, DateTime TradeTime)
        {
            var list_Keys = dict_BSEFOInfo.Keys.ToList();
            foreach (var SocketKey in list_Keys)
            {
                var TextToSend = $"GETLTP^{SpotToken}^{TradeTime:ddMMMyyyy HH:mm:ss}^{EOF}";
                SendString(dict_BSEFOInfo[SocketKey].FeedSocket, TextToSend, SocketKey, en_Segment.BSEFO);
            }
        }
        #endregion

        private void SendString(Socket soc_Sender, string _Message, string SocketKey, en_Segment SEGMENT)
        {
            try
            {
                if (soc_Sender != null && soc_Sender.Connected)
                {
                    byte[] buffer = Encoding.ASCII.GetBytes(_Message);
                    soc_Sender.Send(buffer, 0, buffer.Length, SocketFlags.None);
                }

                #region Old Code. Dont know why I written it like this shit. Changed on 13OCT2021 by Amey.
                ////added try catch to handle FeedReceiver disconnection. 16MAR2021-Amey
                //try
                //{
                //    //add .Connected check on 25JAN2021 by Amey
                //    if (soc_Sender != null && soc_Sender.Connected && (SEGMENT == "" || SEGMENT == "NSEFO"))
                //    {
                //        byte[] buffer = Encoding.ASCII.GetBytes(_Message);
                //        soc_Sender.Send(buffer, 0, buffer.Length, SocketFlags.None);
                //    }
                //}
                //catch (SocketException se)
                //{
                //    dict_FOInfo[SocketKey].IsConnected = false;

                //    eve_ConnectionResponse("FO Feed -CON -SEND : " + _Message + "|" + ((IPEndPoint)soc_Sender.RemoteEndPoint).Port + Environment.NewLine + se);

                //    //added IP and PORT params on 19APR2021 by Amey
                //    FOConnect(IPPORT: SocketKey);
                //}

                ////added try catch to handle FeedReceiver disconnection. 16MAR2021-Amey
                //try
                //{
                //    //add .Connected check on 25JAN2021 by Amey
                //    if (soc_Sender != null && soc_Sender.Connected && (SEGMENT == "" || SEGMENT == "NSECM"))
                //    {
                //        byte[] buffer = Encoding.ASCII.GetBytes(_Message);
                //        soc_Sender.Send(buffer, 0, buffer.Length, SocketFlags.None);
                //    }
                //}
                //catch (SocketException se)
                //{
                //    dict_CMInfo[SocketKey].IsConnected = false;

                //    eve_ConnectionResponse("CM Feed -CON -SEND : " + _Message + "|" + ((IPEndPoint)soc_Sender.RemoteEndPoint).Port + Environment.NewLine + se);

                //    //added IP and PORT params on 19APR2021 by Amey
                //    CMConnect(IPPORT: SocketKey);
                //}

                ////added try catch to handle FeedReceiver disconnection. 16MAR2021-Amey
                //try
                //{
                //    //add .Connected check on 25JAN2021 by Amey
                //    if (soc_Sender != null && soc_Sender.Connected && (SEGMENT == "" || SEGMENT == "BSECM"))
                //    {
                //        byte[] buffer = Encoding.ASCII.GetBytes(_Message);
                //        soc_Sender.Send(buffer, 0, buffer.Length, SocketFlags.None);
                //    }
                //}
                //catch (SocketException se)
                //{
                //    dict_BSECMInfo[SocketKey].IsConnected = false;

                //    eve_ConnectionResponse("BSECM Feed -CON -SEND : " + _Message + "|" + ((IPEndPoint)soc_Sender.RemoteEndPoint).Port + Environment.NewLine + se);

                //    //added IP and PORT params on 19APR2021 by Amey
                //    BSECMConnect(IPPORT: SocketKey);
                //} 
                #endregion
            }
            catch (SocketException se)
            {
                switch (SEGMENT)
                {
                    case en_Segment.NSEFO:
                        dict_FOInfo[SocketKey].IsConnected = false;

                        eve_ConnectionResponse("FO Feed -CON -SEND : " + _Message + "|" + ((IPEndPoint)soc_Sender.RemoteEndPoint).Port + Environment.NewLine + se);

                        //added IP and PORT params on 19APR2021 by Amey
                        FOConnect(IPPORT: SocketKey);
                        break;
                    case en_Segment.NSECM:
                        dict_CMInfo[SocketKey].IsConnected = false;

                        eve_ConnectionResponse("CM Feed -CON -SEND : " + _Message + "|" + ((IPEndPoint)soc_Sender.RemoteEndPoint).Port + Environment.NewLine + se);

                        //added IP and PORT params on 19APR2021 by Amey
                        CMConnect(IPPORT: SocketKey);
                        break;
                    case en_Segment.NSECD:
                        dict_CDInfo[SocketKey].IsConnected = false;

                        eve_ConnectionResponse("CD Feed -CON -SEND : " + _Message + "|" + ((IPEndPoint)soc_Sender.RemoteEndPoint).Port + Environment.NewLine + se);

                        //added IP and PORT params on 19APR2021 by Amey
                        CDConnect(IPPORT: SocketKey);
                        break;
                    case en_Segment.BSECM:
                        dict_BSECMInfo[SocketKey].IsConnected = false;

                        eve_ConnectionResponse("BSECM Feed -CON -SEND : " + _Message + "|" + ((IPEndPoint)soc_Sender.RemoteEndPoint).Port + Environment.NewLine + se);

                        //added IP and PORT params on 19APR2021 by Amey
                        BSECMConnect(IPPORT: SocketKey);
                        break;
                    case en_Segment.BSEFO:
                        dict_BSEFOInfo[SocketKey].IsConnected = false;

                        eve_ConnectionResponse("BSEFO Feed -CON -SEND : " + _Message + "|" + ((IPEndPoint)soc_Sender.RemoteEndPoint).Port + Environment.NewLine + se);

                        //added IP and PORT params on 19APR2021 by Amey
                        BSEFOConnect(IPPORT: SocketKey);
                        break;
                    case en_Segment.MCX:
                        dict_MCXInfo[SocketKey].IsConnected = false;

                        eve_ConnectionResponse("MCX Feed -CON -SEND : " + _Message + "|" + ((IPEndPoint)soc_Sender.RemoteEndPoint).Port + Environment.NewLine + se);

                        //added IP and PORT params on 19APR2021 by Amey
                        MCXConnect(IPPORT: SocketKey);
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ee) { eve_ConnectionResponse("FEED : " + ee); }
        }

        #endregion

        #region Important Methods

        private void FOSeperateAndSendOut(string SocketKey)
        {
            var list_keys = new List<string>();
            var arr_Fields = new string[0];

            int _ReceivedFieldsLength = 0;

            var TickerIndexArgs = new TickerIndexEventArgs();
            var MWArgs = new MWEventArgs();
            var firstPartialCandleArgs = new FirstPartialCandleEventArgs();

            //changed to while true since only one task will be using the task. on 30DEC2022 by Amey.
            while (true)
            {
                list_keys = dict_FOTokenPacket.Keys.ToList();
                try
                {
                    foreach (var _Token in list_keys)
                    {
                        //changed to TryRemove on 23FEB2022 by Amey. To avoid same packet sending continuously.
                        if (dict_FOTokenPacket.TryRemove(_Token, out arr_Fields))
                        {
                            //arr_Fields = dict_FOTokenPacket[_Token];
                            _ReceivedFieldsLength = arr_Fields.Length;

                            switch (arr_Fields[0])
                            {
                                case "7208T" when _ReceivedFieldsLength > 21:
                                    var _Packet7208T = new Packet7208T()
                                    {
                                        Token = arr_Fields[1],
                                        VolumeTradedToday = arr_Fields[2],
                                        LastTradedPrice = arr_Fields[3],
                                        PercentChange = arr_Fields[4],
                                        LastTradeQuantity = arr_Fields[5],
                                        LastTradeTime = arr_Fields[6],
                                        AverageTradePrice = arr_Fields[7],
                                        ClosingPrice = arr_Fields[8],
                                        OpenPrice = arr_Fields[9],
                                        HighPrice = arr_Fields[10],
                                        LowPrice = arr_Fields[11],
                                        BuyPriceDepth = arr_Fields[12],
                                        BuyQuantityDepth = arr_Fields[13],
                                        BuyOrdersDepth = arr_Fields[14],
                                        SellPriceDepth = arr_Fields[15],
                                        SellQuantityDepth = arr_Fields[16],
                                        SellOrdersDepth = arr_Fields[17],
                                        TotalBuyQuantity = arr_Fields[18],
                                        TotalSellQuantity = arr_Fields[19],
                                        OI = arr_Fields[20],
                                        OIPercent = arr_Fields[21],
                                    };

                                    //added on 29MAR2022 by Amey
                                    eve_FO7208TTickReceived(_Packet7208T);
                                    break;
                                case "7208" when _ReceivedFieldsLength > 11:
                                    var args = new MBPEventArgs();
                                    args.Token = arr_Fields[1];
                                    args.VolumeTradedToday = arr_Fields[2];
                                    args.LastTradedPrice = arr_Fields[3];
                                    args.PercentChange = arr_Fields[4];
                                    args.LastTradeQuantity = arr_Fields[5];
                                    args.LastTradeTime = arr_Fields[6];
                                    args.AverageTradePrice = arr_Fields[7];
                                    args.ClosingPrice = arr_Fields[8];
                                    args.OpenPrice = arr_Fields[9];
                                    args.HighPrice = arr_Fields[10];
                                    args.LowPrice = arr_Fields[11];

                                    if (_ReceivedFieldsLength > 15)
                                    {
                                        args.BuyPrice = arr_Fields[12];
                                        args.SellPrice = arr_Fields[14];
                                        args.BuyQuantity = arr_Fields[13];
                                        args.SellQuantity = arr_Fields[15];

                                        if (_ReceivedFieldsLength > 17)
                                        {
                                            args.IV = arr_Fields[16];
                                            args.UnderlyingPrice = arr_Fields[17];

                                            if (_ReceivedFieldsLength > 18)
                                            {
                                                args.MarketVolume = arr_Fields[18];

                                                if (_ReceivedFieldsLength > 22)
                                                {
                                                    args.Delta = arr_Fields[19];
                                                    args.Gamma = arr_Fields[20];
                                                    args.Theta = arr_Fields[21];
                                                    args.Vega = arr_Fields[22];

                                                    //added on 28MAR2022 by Amey
                                                    if (_ReceivedFieldsLength > 25)
                                                    {
                                                        args.TotalBuyQuantity = arr_Fields[23];
                                                        args.TotalSellQuantity = arr_Fields[24];
                                                        args.OI = arr_Fields[25];
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    //changed on 07JAN2021 by Amey
                                    eve_FO7208TickReceived(args);
                                    break;
                                case "7202" when _ReceivedFieldsLength > 3:
                                    TickerIndexArgs.Token = arr_Fields[1];
                                    TickerIndexArgs.Time = arr_Fields[3];
                                    TickerIndexArgs.OpenInterest = arr_Fields[2];
                                    eve_7202TickReceived(TickerIndexArgs);
                                    break;
                                case "FIRST_PARTIAL_CANDLE" when _ReceivedFieldsLength > 7:
                                    firstPartialCandleArgs.Token = arr_Fields[1];
                                    firstPartialCandleArgs.Open = arr_Fields[2];
                                    firstPartialCandleArgs.High = arr_Fields[3];
                                    firstPartialCandleArgs.Low = arr_Fields[4];
                                    firstPartialCandleArgs.Close = arr_Fields[5];
                                    firstPartialCandleArgs.Volume = arr_Fields[6];
                                    firstPartialCandleArgs.CandleTime = arr_Fields[7];
                                    eve_PartialCandleReceived(firstPartialCandleArgs);
                                    break;
                                case "7201":
                                    break;
                                //added on 09JUN2022 by Amey
                                case "7211" when _ReceivedFieldsLength > 19:
                                    var _Packet7211 = new Packet7211Info()
                                    {
                                        Token = arr_Fields[1],
                                        LTP = arr_Fields[2],
                                        BuyQty = arr_Fields[3],
                                        SellQty = arr_Fields[4],
                                        LastActiveTime = arr_Fields[5],
                                        TradedVolume = arr_Fields[6],
                                        TradedValue = arr_Fields[7],
                                        TotalOrderVolume1 = arr_Fields[8],
                                        TotalOrderVolume2 = arr_Fields[9],
                                        Open = arr_Fields[10],
                                        High = arr_Fields[11],
                                        Low = arr_Fields[12],
                                        LastUpdateTime = arr_Fields[13],
                                        BidPriceDepth = arr_Fields[14],
                                        BidQtyDepth = arr_Fields[15],
                                        BidOrdersDepth = arr_Fields[16],
                                        AskPriceDepth = arr_Fields[17],
                                        AskQtyDepth = arr_Fields[18],
                                        AskOrdersDepth = arr_Fields[19]
                                    };

                                    eve_FO7211TickReceived(_Packet7211);
                                    break;
                                case "GETLTP" when _ReceivedFieldsLength > 3:
                                    var _LTPInfo = new LTPInfo()
                                    {
                                        Segment = en_Segment.NSEFO,
                                        Token = arr_Fields[1],
                                        Time = arr_Fields[2],
                                        PriceInPaise = arr_Fields[3]
                                    };

                                    eve_LTPReceived(_LTPInfo);
                                    break;
                                case "1833" when _ReceivedFieldsLength > 11:
                                    var _Packet1833Info = new Packet1833Info()
                                    {
                                        Token = arr_Fields[1],
                                        TotalQtyTraded = arr_Fields[2],
                                        TotValTraded = arr_Fields[3],
                                        PercentChange = arr_Fields[4],
                                        PrevClose = arr_Fields[5],
                                        Open = arr_Fields[6],
                                        High = arr_Fields[7],
                                        Low = arr_Fields[8],
                                        Close = arr_Fields[9],
                                        OI = arr_Fields[10],
                                        OIPercent = arr_Fields[11]
                                    };

                                    eve_FO1833Received(_Packet1833Info);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
                catch (Exception ee) { eve_ConnectionResponse("FO Feed -IN " + Environment.NewLine + ee); }

                Thread.Sleep(50);
            }
        }

        private void CDSeperateAndSendOut(string SocketKey)
        {
            var list_keys = new List<string>();
            var arr_Fields = new string[0];

            int _ReceivedFieldsLength = 0;

            var TickerIndexArgs = new TickerIndexEventArgs();
            var MWArgs = new MWEventArgs();
            var firstPartialCandleArgs = new FirstPartialCandleEventArgs();

            //changed to while true since only one task will be using the task. on 30DEC2022 by Amey.
            while (true)
            {
                list_keys = dict_CDTokenPacket.Keys.ToList();
                try
                {
                    foreach (var _Token in list_keys)
                    {
                        //changed to TryRemove on 23FEB2022 by Amey. To avoid same packet sending continuously.
                        if (dict_CDTokenPacket.TryRemove(_Token, out arr_Fields))
                        {
                            //arr_Fields = dict_CDTokenPacket[_Token];
                            _ReceivedFieldsLength = arr_Fields.Length;

                            switch (arr_Fields[0])
                            {
                                case "7208T" when _ReceivedFieldsLength > 20:
                                    var _Packet7208T = new Packet7208T()
                                    {
                                        Token = arr_Fields[1],
                                        VolumeTradedToday = arr_Fields[2],
                                        LastTradedPrice = arr_Fields[3],
                                        PercentChange = arr_Fields[4],
                                        LastTradeQuantity = arr_Fields[5],
                                        LastTradeTime = arr_Fields[6],
                                        AverageTradePrice = arr_Fields[7],
                                        ClosingPrice = arr_Fields[8],
                                        OpenPrice = arr_Fields[9],
                                        HighPrice = arr_Fields[10],
                                        LowPrice = arr_Fields[11],
                                        BuyPriceDepth = arr_Fields[12],
                                        BuyQuantityDepth = arr_Fields[13],
                                        BuyOrdersDepth = arr_Fields[14],
                                        SellPriceDepth = arr_Fields[15],
                                        SellQuantityDepth = arr_Fields[16],
                                        SellOrdersDepth = arr_Fields[17],
                                        TotalBuyQuantity = arr_Fields[18],
                                        TotalSellQuantity = arr_Fields[19],
                                        OI = arr_Fields[20],
                                    };
                                    
                                    //added on 29MAR2022 by Amey
                                    eve_CD7208TTickReceived(_Packet7208T);
                                    break;
                                case "7208" when _ReceivedFieldsLength > 11:
                                    var args = new MBPEventArgs();

                                    args.Token = arr_Fields[1];
                                    args.VolumeTradedToday = arr_Fields[2];
                                    args.LastTradedPrice = arr_Fields[3];
                                    args.PercentChange = arr_Fields[4];
                                    args.LastTradeQuantity = arr_Fields[5];
                                    args.LastTradeTime = arr_Fields[6];
                                    args.AverageTradePrice = arr_Fields[7];
                                    args.ClosingPrice = arr_Fields[8];
                                    args.OpenPrice = arr_Fields[9];
                                    args.HighPrice = arr_Fields[10];
                                    args.LowPrice = arr_Fields[11];

                                    if (_ReceivedFieldsLength > 15)
                                    {
                                        args.BuyPrice = arr_Fields[12];
                                        args.SellPrice = arr_Fields[14];
                                        args.BuyQuantity = arr_Fields[13];
                                        args.SellQuantity = arr_Fields[15];

                                        if (_ReceivedFieldsLength > 17)
                                        {
                                            args.IV = arr_Fields[16];
                                            args.UnderlyingPrice = arr_Fields[17];

                                            if (_ReceivedFieldsLength > 18)
                                            {
                                                args.MarketVolume = arr_Fields[18];

                                                if (_ReceivedFieldsLength > 22)
                                                {
                                                    args.Delta = arr_Fields[19];
                                                    args.Gamma = arr_Fields[20];
                                                    args.Theta = arr_Fields[21];
                                                    args.Vega = arr_Fields[22];

                                                    //added on 28MAR2022 by Amey
                                                    if (_ReceivedFieldsLength > 25)
                                                    {
                                                        args.TotalBuyQuantity = arr_Fields[23];
                                                        args.TotalSellQuantity = arr_Fields[24];
                                                        args.OI = arr_Fields[25];
                                                    }
                                                }
                                            }
                                        }
                                    }
                                   
                                    //changed on 07JAN2021 by Amey
                                    eve_CD7208TickReceived(args);
                                    break;
                                case "7202" when _ReceivedFieldsLength > 3:
                                    TickerIndexArgs.Token = arr_Fields[1];
                                    TickerIndexArgs.Time = arr_Fields[3];
                                    TickerIndexArgs.OpenInterest = arr_Fields[2];
                                    eve_7202TickReceived(TickerIndexArgs);
                                    break;
                                case "FIRST_PARTIAL_CANDLE" when _ReceivedFieldsLength > 7:
                                    firstPartialCandleArgs.Token = arr_Fields[1];
                                    firstPartialCandleArgs.Open = arr_Fields[2];
                                    firstPartialCandleArgs.High = arr_Fields[3];
                                    firstPartialCandleArgs.Low = arr_Fields[4];
                                    firstPartialCandleArgs.Close = arr_Fields[5];
                                    firstPartialCandleArgs.Volume = arr_Fields[6];
                                    firstPartialCandleArgs.CandleTime = arr_Fields[7];
                                    eve_PartialCandleReceived(firstPartialCandleArgs);
                                    break;
                                case "7201":
                                    break;
                                case "GETLTP" when _ReceivedFieldsLength > 3:
                                    var _LTPInfo = new LTPInfo()
                                    {
                                        Segment = en_Segment.NSECD,
                                        Token = arr_Fields[1],
                                        Time = arr_Fields[2],
                                        PriceInPaise = arr_Fields[3]
                                    };

                                    eve_LTPReceived(_LTPInfo);
                                    break;
                                case "1833" when _ReceivedFieldsLength > 11:
                                    var _Packet1833Info = new Packet1833Info()
                                    {
                                        Token = arr_Fields[1],
                                        TotalQtyTraded = arr_Fields[2],
                                        TotValTraded = arr_Fields[3],
                                        PercentChange = arr_Fields[4],
                                        PrevClose = arr_Fields[5],
                                        Open = arr_Fields[6],
                                        High = arr_Fields[7],
                                        Low = arr_Fields[8],
                                        Close = arr_Fields[9],
                                        OI = arr_Fields[10],
                                        OIPercent = arr_Fields[11]
                                    };

                                    eve_CD1833Received(_Packet1833Info);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
                catch (Exception ee) { eve_ConnectionResponse("CD Feed -IN " + Environment.NewLine + ee); }

                Thread.Sleep(50);
            }
        }

        private void CMSeperateAndSendOut(string SocketKey)
        {
            var list_keys = new List<string>();
            var arr_Fields = new string[0];

            int _ReceivedFieldsLength = 0;

            var TickerIndexArgs = new TickerIndexEventArgs();
            var MWArgs = new MWEventArgs();
            var firstPartialCandleArgs = new FirstPartialCandleEventArgs();

            //changed to while true since only one task will be using the task. on 30DEC2022 by Amey.
            while (true)
            {
                list_keys = dict_CMTokenPacket.Keys.ToList();
                try
                {
                    foreach (var _Token in list_keys)
                    {
                        //changed to TryRemove on 23FEB2022 by Amey. To avoid same packet sending continuously.
                        if (dict_CMTokenPacket.TryRemove(_Token, out arr_Fields))
                        {
                            //arr_Fields = dict_CMTokenPacket[_Token];
                            _ReceivedFieldsLength = arr_Fields.Length;

                            switch (arr_Fields[0])
                            {
                                case "7208T" when _ReceivedFieldsLength > 19:
                                    var _Packet7208T = new Packet7208T()
                                    {
                                        Token = arr_Fields[1],
                                        VolumeTradedToday = arr_Fields[2],
                                        LastTradedPrice = arr_Fields[3],
                                        PercentChange = arr_Fields[4],
                                        LastTradeQuantity = arr_Fields[5],
                                        LastTradeTime = arr_Fields[6],
                                        AverageTradePrice = arr_Fields[7],
                                        ClosingPrice = arr_Fields[8],
                                        OpenPrice = arr_Fields[9],
                                        HighPrice = arr_Fields[10],
                                        LowPrice = arr_Fields[11],
                                        BuyPriceDepth = arr_Fields[12],
                                        BuyQuantityDepth = arr_Fields[13],
                                        BuyOrdersDepth = arr_Fields[14],
                                        SellPriceDepth = arr_Fields[15],
                                        SellQuantityDepth = arr_Fields[16],
                                        SellOrdersDepth = arr_Fields[17],
                                        TotalBuyQuantity = arr_Fields[18],
                                        TotalSellQuantity = arr_Fields[19],
                                    };

                                    //added on 29MAR2022 by Amey
                                    eve_CM7208TTickReceived(_Packet7208T);
                                    break;
                                case "7208" when _ReceivedFieldsLength > 11:
                                    var args = new MBPEventArgs();

                                    args.Token = arr_Fields[1];
                                    args.VolumeTradedToday = arr_Fields[2];
                                    args.LastTradedPrice = arr_Fields[3];
                                    args.PercentChange = arr_Fields[4];
                                    args.LastTradeQuantity = arr_Fields[5];
                                    args.LastTradeTime = arr_Fields[6];
                                    args.AverageTradePrice = arr_Fields[7];
                                    args.ClosingPrice = arr_Fields[8];
                                    args.OpenPrice = arr_Fields[9];
                                    args.HighPrice = arr_Fields[10];
                                    args.LowPrice = arr_Fields[11];

                                    //added on 23OCT2020 by Amey.
                                    if (_ReceivedFieldsLength > 15)
                                    {
                                        args.BuyPrice = arr_Fields[12];
                                        args.SellPrice = arr_Fields[14];
                                        args.BuyQuantity = arr_Fields[13];
                                        args.SellQuantity = arr_Fields[15];

                                        if (_ReceivedFieldsLength > 16)
                                            args.MarketVolume = arr_Fields[16];

                                        //added on 28MAR2022 by Amey
                                        if (_ReceivedFieldsLength > 18)
                                        {
                                            args.TotalBuyQuantity = arr_Fields[17];
                                            args.TotalSellQuantity = arr_Fields[18];
                                        }
                                    }

                                    //changed on 07JAN2021 by Amey
                                    eve_CM7208TickReceived(args);
                                    break;
                                case "7202" when _ReceivedFieldsLength > 3:
                                    TickerIndexArgs.Token = arr_Fields[1];
                                    TickerIndexArgs.Time = arr_Fields[3];
                                    TickerIndexArgs.OpenInterest = arr_Fields[2];
                                    eve_7202TickReceived(TickerIndexArgs);
                                    break;
                                case "FIRST_PARTIAL_CANDLE" when _ReceivedFieldsLength > 7:
                                    firstPartialCandleArgs.Token = arr_Fields[1];
                                    firstPartialCandleArgs.Open = arr_Fields[2];
                                    firstPartialCandleArgs.High = arr_Fields[3];
                                    firstPartialCandleArgs.Low = arr_Fields[4];
                                    firstPartialCandleArgs.Close = arr_Fields[5];
                                    firstPartialCandleArgs.Volume = arr_Fields[6];
                                    firstPartialCandleArgs.CandleTime = arr_Fields[7];
                                    eve_PartialCandleReceived(firstPartialCandleArgs);
                                    break;
                                case "7201":
                                    break;
                                case "GETLTP" when _ReceivedFieldsLength > 3:
                                    var _LTPInfo = new LTPInfo()
                                    {
                                        Segment = en_Segment.NSECM,
                                        Token = arr_Fields[1],
                                        Time = arr_Fields[2],
                                        PriceInPaise = arr_Fields[3]
                                    };

                                    eve_LTPReceived(_LTPInfo);
                                    break;
                                case "1833" when _ReceivedFieldsLength > 9:
                                    var _Packet1833Info = new Packet1833Info()
                                    {
                                        Token = arr_Fields[1],
                                        TotalQtyTraded = arr_Fields[2],
                                        TotValTraded = arr_Fields[3],
                                        PercentChange = arr_Fields[4],
                                        PrevClose = arr_Fields[5],
                                        Open = arr_Fields[6],
                                        High = arr_Fields[7],
                                        Low = arr_Fields[8],
                                        Close = arr_Fields[9]
                                    };

                                    eve_CM1833Received(_Packet1833Info);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
                catch (Exception ee) { eve_ConnectionResponse("CM Feed -IN " + Environment.NewLine + ee); }

                Thread.Sleep(50);
            }
        }

        private void BSECMSeperateAndSendOut(string SocketKey)
        {
            var list_keys = new List<string>();
            var arr_Fields = new string[0];

            int _ReceivedFieldsLength = 0;

            //changed to while true since only one task will be using the task. on 30DEC2022 by Amey.
            while (true)
            {
                list_keys = dict_BSECMTokenPacket.Keys.ToList();
                try
                {
                    foreach (var _Token in list_keys)
                    {
                        //changed to TryRemove on 23FEB2022 by Amey. To avoid same packet sending continuously.
                        if (dict_BSECMTokenPacket.TryRemove(_Token, out arr_Fields))
                        {
                            //arr_Fields = dict_BSECMTokenPacket[_Token];
                            _ReceivedFieldsLength = arr_Fields.Length;

                            switch (arr_Fields[0])
                            {
                                case "7208" when _ReceivedFieldsLength > 11:
                                    //var args = new BSECMPacket();

                                    //args.Token = arr_Fields[1];
                                    //args.VolumeTradedToday = arr_Fields[2];
                                    //args.LTP = arr_Fields[3];
                                    //args.LTQ = arr_Fields[4];
                                    //args.Open = arr_Fields[5];
                                    //args.High = arr_Fields[6];
                                    //args.Low = arr_Fields[7];
                                    //args.Close = arr_Fields[8];
                                    //args.PreviousClose = arr_Fields[9];
                                    //args.AvgPrice = arr_Fields[10];
                                    //args.list_BidAskDepth = arr_Fields[11];

                                    var _BSECMPacket = new BSECMPacket()
                                    {
                                        Token = arr_Fields[1],
                                        Open = arr_Fields[2],
                                        High = arr_Fields[3],
                                        Low = arr_Fields[4],
                                        Close = arr_Fields[5],
                                        PreviousClose = arr_Fields[6],
                                        LTP = arr_Fields[7],
                                        LTQ = arr_Fields[8],
                                        AvgPrice = arr_Fields[10],
                                        list_BidAskDepth = arr_Fields[11],
                                    };

                                    //changed on 07JAN2021 by Amey
                                    eve_BSECMTickReceived(_BSECMPacket);
                                    break;
                                case "GETLTP" when _ReceivedFieldsLength > 3:
                                    var _LTPInfo = new LTPInfo()
                                    {
                                        Segment = en_Segment.BSECM,
                                        Token = arr_Fields[1],
                                        Time = arr_Fields[2],
                                        PriceInPaise = arr_Fields[3]
                                    };

                                    eve_LTPReceived(_LTPInfo);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
                catch (Exception ee) { eve_ConnectionResponse("BSECM Feed -IN " + Environment.NewLine + ee); }

                Thread.Sleep(50);
            }
        }

        //added by Omkar
        private void BSEFOSeperateAndSendOut(string SocketKey)
        {
            var list_keys = new List<string>();
            var arr_Fields = new string[0];

            int _ReceivedFieldsLength = 0;

            //changed to while true since only one task will be using the task. on 30DEC2022 by Amey.
            while (true)
            {
                list_keys = dict_BSEFOTokenPacket.Keys.ToList();
                try
                {
                    foreach (var _Token in list_keys)
                    {
                        //changed to TryRemove on 23FEB2022 by Amey. To avoid same packet sending continuously.
                        if (dict_BSEFOTokenPacket.TryRemove(_Token, out arr_Fields))
                        {
                            //arr_Fields = dict_BSEFOTokenPacket[_Token];
                            _ReceivedFieldsLength = arr_Fields.Length;

                            switch (arr_Fields[0])
                            {
                                case "7208" when _ReceivedFieldsLength > 11:
                                    var args = new BSEFOPacket();

                                    args.Token = arr_Fields[1]; //token
                                    args.VolumeTradedToday = arr_Fields[12]; // total trade
                                    args.LTP = arr_Fields[2]; //
                                    args.LTQ = arr_Fields[3]; 
                                    args.Open = arr_Fields[5];
                                    args.High = arr_Fields[6];
                                    args.Low = arr_Fields[7];
                                    args.Close = arr_Fields[8];
                                    args.PreviousClose = arr_Fields[8];//doubt
                                    args.AvgPrice = arr_Fields[11];
                                    args.list_BidAskDepth = arr_Fields[15];//doubt

                                    args.IV = arr_Fields[16];
                                    args.UnderlyingPrice = arr_Fields[17];
                                    args.Delta = arr_Fields[18];
                                    args.Gamma = arr_Fields[19];
                                    args.Theta = arr_Fields[20];
                                    args.Vega = arr_Fields[21];

                                    //changed on 07JAN2021 by Amey
                                    eve_BSEFOTickReceived(args);
                                    break;
                                case "GETLTP" when _ReceivedFieldsLength > 3:
                                    var _LTPInfo = new LTPInfo()
                                    {
                                        Segment = en_Segment.BSEFO,
                                        Token = arr_Fields[1],
                                        Time = arr_Fields[2],
                                        PriceInPaise = arr_Fields[3]
                                    };

                                    eve_LTPReceived(_LTPInfo);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
                catch (Exception ee) { eve_ConnectionResponse("BSEFO Feed -IN " + Environment.NewLine + ee); }

                Thread.Sleep(50);
            }
        }

        private void MCXSeperateAndSendOut(string SocketKey)
        {
            var list_keys = new List<string>();
            var arr_Fields = new string[0];

            int _ReceivedFieldsLength = 0;

            //changed to while true since only one task will be using the task. on 30DEC2022 by Amey.
            while (true)
            {
                list_keys = dict_MCXTokenPacket.Keys.ToList();
                try
                {
                    foreach (var _Token in list_keys)
                    {
                        //changed to TryRemove on 23FEB2022 by Amey. To avoid same packet sending continuously.
                        if (dict_MCXTokenPacket.TryRemove(_Token, out arr_Fields))
                        {
                            //arr_Fields = dict_MCXTokenPacket[_Token];
                            _ReceivedFieldsLength = arr_Fields.Length;

                            switch (arr_Fields[0])
                            {
                                case "7208" when _ReceivedFieldsLength > 15:
                                    var args = new MCXPacket();

                                    args.Token = arr_Fields[1];
                                    args.LTP = arr_Fields[2];
                                    args.LTQ = arr_Fields[3];
                                    args.LTT = arr_Fields[4];
                                    args.Open = arr_Fields[5];
                                    args.High = arr_Fields[6];
                                    args.Low = arr_Fields[7];
                                    args.Close = arr_Fields[8];
                                    args.TotalBuyQty = arr_Fields[9];
                                    args.TotalSellQty = arr_Fields[10];
                                    args.AvgPrice = arr_Fields[11];
                                    args.TotalTrades = arr_Fields[12];
                                    args.OpenInterest = arr_Fields[13];
                                    args.Multiplier = arr_Fields[14];
                                    args.list_BidAskDepth = arr_Fields[15];

                                    eve_MCXTickReceived(args);
                                    break;
                                case "GETLTP" when _ReceivedFieldsLength > 3:
                                    var _LTPInfo = new LTPInfo()
                                    {
                                        Segment = en_Segment.MCX,
                                        Token = arr_Fields[1],
                                        Time = arr_Fields[2],
                                        PriceInPaise = arr_Fields[3]
                                    };

                                    eve_LTPReceived(_LTPInfo);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
                catch (Exception ee) { eve_ConnectionResponse("MCX Feed -IN " + Environment.NewLine + ee); }

                Thread.Sleep(50);
            }
        }

        #endregion

        #region Supplimentary Methods

        /// <summary>
        /// Converts value to double.
        /// </summary>
        /// <param name="Value">Pass string value.</param>
        /// <returns>Value</returns>
        private static double DBL(string Value) => Convert.ToDouble(Value);

        /// <summary>
        /// Converts value to int.
        /// </summary>
        /// <param name="Value">Pass string value.</param>
        /// <returns>Value</returns>
        private static int INT(string Value) => Convert.ToInt32(Value);

        /// <summary>
        /// Converts value to long.
        /// </summary>
        /// <param name="Value">Pass string value.</param>
        /// <returns>Value</returns>
        private static long LONG(string Value) => Convert.ToInt64(Value);

        #endregion
    }
}